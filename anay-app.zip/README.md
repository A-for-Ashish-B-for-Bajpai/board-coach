# Board Coach v0.1 — how to put it on Anay's phone (free, about 15 minutes)

Subjects: Science, Maths, Social Science (History, Geography, Civics, Economics), Communicative English, Hindi-B and Artificial Intelligence. 326 practice questions, quick mocks for every subject, and links to the official CBSE 2026-27 sample papers.

Board Coach is a small web app. Once it is online, Anay installs it from Chrome like a normal app, and it then works without internet. Progress is saved only on the phone.

## Option A: GitHub Pages (free)

1. On a computer, unzip `anay-app.zip`. You will see `index.html`, `app.js`, `questions.js`, `more-subjects.js`, `sw.js`, `manifest.webmanifest` and an `icons` folder.
2. Go to github.com and create a free account (skip if you have one).
3. Click **New repository**. Name it `board-coach`, choose **Public**, and click **Create repository**.
4. Click **uploading an existing file**. Drag in all the files **and** the `icons` folder. Click **Commit changes**.
5. Open **Settings → Pages**. Under "Branch" choose `main` and `/ (root)`, then click **Save**.
6. Wait 1 to 2 minutes. Your app is at `https://YOUR-USERNAME.github.io/board-coach/`.

The repository is public, but it only holds the app and questions. No personal data is ever uploaded: Anay's progress stays on the phone.

## Option B: Netlify Drop (no GitHub needed)

Go to app.netlify.com/drop, sign up free, and drag the unzipped folder onto the page. Netlify gives you a link like `https://something.netlify.app`.

## Install on Anay's phone

1. Open the link in **Chrome** on Anay's phone while online.
2. Tap the **⋮** menu, then **Install app** (or **Add to Home screen**).
3. Open the app once from the home screen, then turn on airplane mode and open it again to check it works offline.
4. In the app, tap the gear icon and set the first board exam date when the 2027 date sheet is out (default: 17 Feb 2027).
5. For full mock papers, open each official sample paper PDF once while online and download it, so it opens offline too. The Hindi-B and AI buttons open CBSE's sample paper page; pick the paper there.

## Weekly habit

- Every Sunday: Settings → **Save backup**, and keep the file in Google Drive.
- Ask Anay for 10 minutes of feedback: what was useful, what was annoying, any wrong answers.

## Adding questions

Science and Maths questions are in `questions.js`; the other subjects are in `more-subjects.js`. Copy any question line, and change the text, options, answer (`a: 0` means the first option) and explanation. Upload the changed file the same way. The app updates the next time Anay opens it online.

## Please check

The English literature and Hindi-B chapter lists come from the standard CBSE books (Interact in English Literature Reader; Sparsh and Sanchayan). If Anay's school has dropped a chapter, just skip its questions or delete them from `more-subjects.js`.
