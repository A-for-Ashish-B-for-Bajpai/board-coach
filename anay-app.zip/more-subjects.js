// More subjects: Social Science, Communicative English, Hindi-B, Artificial Intelligence.
// Loaded after questions.js. Same question format: s, ch, q, o, a (index of the right option), e.

const SUBJECTS = [
  { k: "sci", n: "Science" },
  { k: "math", n: "Maths" },
  { k: "sst", n: "Social Science" },
  { k: "eng", n: "English" },
  { k: "hin", n: "Hindi-B" },
  { k: "ai", n: "AI" }
];

CHAPTERS.sst = [
  "History: The Rise of Nationalism in Europe",
  "History: Nationalism in India",
  "History: The Making of a Global World",
  "History: The Age of Industrialisation",
  "History: Print Culture and the Modern World",
  "Geography: Resources and Development",
  "Geography: Forest and Wildlife Resources",
  "Geography: Water Resources",
  "Geography: Agriculture",
  "Geography: Minerals and Energy Resources",
  "Geography: Manufacturing Industries",
  "Geography: Lifelines of National Economy",
  "Civics: Power Sharing",
  "Civics: Federalism",
  "Civics: Gender, Religion and Caste",
  "Civics: Political Parties",
  "Civics: Outcomes of Democracy",
  "Economics: Development",
  "Economics: Sectors of the Indian Economy",
  "Economics: Money and Credit",
  "Economics: Globalisation and the Indian Economy"
];
// Communicative English (code 101): grammar topics from the 2026-27 syllabus, then the Literature Reader.
// Literature list is from the Interact in English Literature Reader; check it against Anay's book.
CHAPTERS.eng = [
  "Grammar: Tenses",
  "Grammar: Modals",
  "Grammar: Subject-verb agreement",
  "Grammar: Reported speech",
  "Grammar: Clauses",
  "Grammar: Determiners",
  "Literature: Prose",
  "Literature: Poetry",
  "Literature: Drama"
];
CHAPTERS.hin = [
  "व्याकरण: पदबंध",
  "व्याकरण: रचना के आधार पर वाक्य भेद",
  "व्याकरण: समास",
  "व्याकरण: मुहावरे",
  "स्पर्श: गद्य खंड",
  "स्पर्श: काव्य खंड",
  "संचयन"
];
// Artificial Intelligence (code 417), Part B units, plus Part A employability skills.
CHAPTERS.ai = [
  "AI Project Cycle and AI Ethics",
  "Advanced Concepts of Modelling",
  "Evaluating Models",
  "Statistical Data",
  "Computer Vision",
  "Natural Language Processing",
  "Employability Skills"
];

NCERT_BOOKS.sst = "https://ncert.nic.in/textbook.php";
NCERT_BOOKS.hin = "https://ncert.nic.in/textbook.php";
NCERT_BOOKS.eng = null; // Interact in English books are published by CBSE, not NCERT
NCERT_BOOKS.ai = null;

SAMPLE_PAPERS.push(
  { s: "sst", title: "Social Science sample paper 2026-27", url: "https://cbseacademic.nic.in/web_material/SQP/ClassX_2026_27/SocialScience-SQP.pdf", ms: "https://cbseacademic.nic.in/web_material/SQP/ClassX_2026_27/SocialScience-MS.pdf", marks: 80, minutes: 180 },
  { s: "eng", title: "English Communicative sample paper 2026-27", url: "https://cbseacademic.nic.in/web_material/SQP/ClassX_2026_27/EnglishComm-SQP.pdf", marks: 80, minutes: 180 },
  { s: "hin", title: "Hindi Course B sample paper 2026-27 (on CBSE's sample paper page)", url: SQP_PAGE, marks: 80, minutes: 180 },
  { s: "ai", title: "Artificial Intelligence (417) sample paper (on CBSE's sample paper page)", url: SQP_PAGE, marks: 50, minutes: 120 }
);

QUESTIONS.push(
  // ---------- SOCIAL SCIENCE ----------
  // 1 Rise of Nationalism in Europe
  { s: "sst", ch: 1, q: "In 1848, Frédéric Sorrieu made a series of prints showing his dream of:", o: ["A world of empires", "A world of democratic and social republics", "A united Christian church", "A world without trade"], a: 1, e: "Sorrieu's prints imagine peoples of Europe and America marching towards the Statue of Liberty, a world of democratic and social republics." },
  { s: "sst", ch: 1, q: "Giuseppe Mazzini founded which secret society?", o: ["Young Italy", "Red Shirts", "Carbonari", "Zollverein"], a: 0, e: "Mazzini founded Young Italy in Marseilles and later Young Europe in Berne." },
  { s: "sst", ch: 1, q: "Germany was unified under the leadership of:", o: ["Count Cavour", "Otto von Bismarck", "Garibaldi", "Napoleon III"], a: 1, e: "Prussian chief minister Otto von Bismarck led the unification. Kaiser William I was proclaimed German Emperor at Versailles in January 1871." },
  { s: "sst", ch: 1, q: "The Treaty of Vienna (1815) aimed to:", o: ["Spread democracy across Europe", "Undo most changes made during the Napoleonic wars and restore monarchies", "Unify Italy", "Abolish serfdom"], a: 1, e: "The conservative Congress of Vienna restored the Bourbon dynasty and undid many Napoleonic changes." },
  { s: "sst", ch: 1, q: "Which treaty recognised Greece as an independent nation?", o: ["Treaty of Versailles, 1871", "Treaty of Vienna, 1815", "Treaty of Constantinople, 1832", "Treaty of Paris, 1856"], a: 2, e: "After the Greek war of independence, the Treaty of Constantinople of 1832 recognised Greece." },
  { s: "sst", ch: 1, q: "The female allegory Marianne represented:", o: ["Germany", "Italy", "France", "Britain"], a: 2, e: "Marianne stood for France; Germania stood for Germany." },
  // 2 Nationalism in India
  { s: "sst", ch: 2, q: "The Jallianwala Bagh massacre took place on 13 April 1919 in:", o: ["Lahore", "Amritsar", "Delhi", "Lucknow"], a: 1, e: "General Dyer ordered firing on an unarmed crowd in Jallianwala Bagh, Amritsar." },
  { s: "sst", ch: 2, q: "Gandhiji called off the Non-Cooperation Movement in 1922 after the violence at:", o: ["Champaran", "Chauri Chaura", "Kheda", "Dandi"], a: 1, e: "After a clash at Chauri Chaura in February 1922 turned violent, Gandhiji withdrew the movement." },
  { s: "sst", ch: 2, q: "The Salt March from Sabarmati to Dandi began in:", o: ["1919", "1922", "1930", "1942"], a: 2, e: "Gandhiji started the march on 12 March 1930, launching the Civil Disobedience Movement." },
  { s: "sst", ch: 2, q: "The Poona Pact of 1932 was signed between Gandhiji and:", o: ["Jawaharlal Nehru", "Dr B. R. Ambedkar", "Muhammad Ali Jinnah", "Subhas Chandra Bose"], a: 1, e: "It gave reserved seats to the Depressed Classes in provincial and central councils, voted in by the general electorate." },
  { s: "sst", ch: 2, q: "The demand for Purna Swaraj (complete independence) was formalised at the Lahore Congress session of:", o: ["December 1929", "December 1920", "August 1942", "April 1919"], a: 0, e: "The Lahore session in December 1929, under Jawaharlal Nehru, adopted Purna Swaraj as the goal." },
  { s: "sst", ch: 2, q: "The famous image of Bharat Mata was painted by:", o: ["Raja Ravi Varma", "Abanindranath Tagore", "Rabindranath Tagore", "Nandalal Bose"], a: 1, e: "Abanindranath Tagore's Bharat Mata shows her as calm, composed and spiritual." },
  // 3 Making of a Global World
  { s: "sst", ch: 3, q: "Rinderpest, which spread in Africa in the 1890s, was a disease of:", o: ["Wheat crops", "Cattle", "Humans", "Rubber trees"], a: 1, e: "Rinderpest killed about 90% of cattle and destroyed African livelihoods, which helped colonisers control labour." },
  { s: "sst", ch: 3, q: "The Bretton Woods conference of 1944 set up:", o: ["The UN and WTO", "The IMF and the World Bank", "The G-77", "The League of Nations"], a: 1, e: "The International Monetary Fund and the World Bank (IBRD) are called the Bretton Woods twins." },
  { s: "sst", ch: 3, q: "The Corn Laws in Britain:", o: ["Allowed free import of corn", "Restricted the import of corn", "Banned corn farming", "Fixed wages of farm workers"], a: 1, e: "The Corn Laws restricted imports of corn to protect landed groups. Their removal made food cheaper." },
  { s: "sst", ch: 3, q: "The Great Depression began around:", o: ["1914", "1929", "1945", "1960"], a: 1, e: "The Depression began around 1929 and lasted till the mid-1930s." },
  // 4 Age of Industrialisation
  { s: "sst", ch: 4, q: "Large-scale production for international markets in the countryside, before factories, is called:", o: ["Proto-industrialisation", "Globalisation", "Liberalisation", "De-industrialisation"], a: 0, e: "Proto-industrialisation was based in homes, organised by merchants, before the factory age." },
  { s: "sst", ch: 4, q: "In India, a gomastha was:", o: ["A weaver", "A paid servant of the East India Company who supervised weavers", "A moneylender", "A factory owner"], a: 1, e: "Gomasthas collected supplies and checked cloth quality for the Company." },
  { s: "sst", ch: 4, q: "The first cotton mill in Bombay came up in:", o: ["1854", "1874", "1900", "1917"], a: 0, e: "The first cotton mill in Bombay was set up in 1854." },
  { s: "sst", ch: 4, q: "The Spinning Jenny was invented by:", o: ["James Watt", "Richard Arkwright", "James Hargreaves", "Thomas Edison"], a: 2, e: "James Hargreaves devised the Spinning Jenny in 1764, letting one worker turn many spindles." },
  // 5 Print Culture
  { s: "sst", ch: 5, q: "Johann Gutenberg developed the first known printing press in the:", o: ["1230s", "1430s", "1630s", "1830s"], a: 1, e: "Gutenberg built his press by the 1430s. The first book he printed was the Bible." },
  { s: "sst", ch: 5, q: "Martin Luther wrote the Ninety Five Theses in:", o: ["1517", "1617", "1717", "1817"], a: 0, e: "His 1517 criticism of the Roman Catholic Church was widely printed and led to the Protestant Reformation." },
  { s: "sst", ch: 5, q: "The printing press first came to India with:", o: ["British officials in Calcutta", "Portuguese missionaries in Goa", "Mughal emperors", "Dutch traders in Surat"], a: 1, e: "Portuguese missionaries brought the press to Goa in the mid-16th century." },
  { s: "sst", ch: 5, q: "The Vernacular Press Act, which gave the government power to censor Indian-language newspapers, was passed in:", o: ["1857", "1878", "1905", "1919"], a: 1, e: "The Act of 1878 was modelled on the Irish Press Laws." },
  // 6 Resources and Development
  { s: "sst", ch: 6, q: "The most widespread soil in India is:", o: ["Black soil", "Alluvial soil", "Laterite soil", "Arid soil"], a: 1, e: "Alluvial soil covers the northern plains and river deltas and is very fertile." },
  { s: "sst", ch: 6, q: "Black soil (regur) is ideal for growing:", o: ["Tea", "Cotton", "Rice", "Coffee"], a: 1, e: "Black soil holds moisture well, which suits cotton." },
  { s: "sst", ch: 6, q: "The first Earth Summit was held in 1992 at:", o: ["Kyoto", "Rio de Janeiro", "New York", "Paris"], a: 1, e: "The Rio de Janeiro summit adopted Agenda 21 for sustainable development." },
  { s: "sst", ch: 6, q: "Laterite soil develops mainly due to:", o: ["Deposition by rivers", "Intense leaching in high temperature and heavy rainfall", "Volcanic lava", "Wind deposits"], a: 1, e: "Heavy rain washes out nutrients (leaching), leaving laterite soil." },
  // 7 Forest and Wildlife
  { s: "sst", ch: 7, q: "Project Tiger was launched in:", o: ["1972", "1973", "1988", "1992"], a: 1, e: "Project Tiger began in 1973 to save India's tigers." },
  { s: "sst", ch: 7, q: "The Indian Wildlife (Protection) Act was passed in:", o: ["1952", "1972", "1980", "1986"], a: 1, e: "The 1972 Act set up protected areas and banned hunting of protected species." },
  { s: "sst", ch: 7, q: "The Chipko movement started in the:", o: ["Western Ghats", "Himalayas", "Thar Desert", "Sundarbans"], a: 1, e: "Villagers hugged trees in the Himalayas to stop them being cut." },
  { s: "sst", ch: 7, q: "Joint Forest Management (JFM) was first started in 1988 in:", o: ["Odisha", "Kerala", "Gujarat", "Punjab"], a: 0, e: "Odisha passed the first JFM resolution, involving local communities in protecting degraded forests." },
  // 8 Water Resources
  { s: "sst", ch: 8, q: "The Hirakud Dam is built on the river:", o: ["Sutlej", "Mahanadi", "Narmada", "Krishna"], a: 1, e: "Hirakud is on the Mahanadi in Odisha." },
  { s: "sst", ch: 8, q: "Who called dams the 'temples of modern India'?", o: ["Mahatma Gandhi", "Jawaharlal Nehru", "Sardar Patel", "B. R. Ambedkar"], a: 1, e: "Jawaharlal Nehru said this, hoping dams would combine farming and industrial growth." },
  { s: "sst", ch: 8, q: "In semi-arid Rajasthan, 'tankas' are:", o: ["Water channels in hills", "Underground tanks to store rainwater", "Dams", "Canals"], a: 1, e: "Tankas are underground tanks linked to sloping roofs to collect rainwater, common in Bikaner and Phalodi." },
  { s: "sst", ch: 8, q: "The Sardar Sarovar Dam is built on the river:", o: ["Narmada", "Ganga", "Godavari", "Kaveri"], a: 0, e: "Sardar Sarovar is on the Narmada in Gujarat." },
  // 9 Agriculture
  { s: "sst", ch: 9, q: "Which is a rabi crop?", o: ["Rice", "Cotton", "Wheat", "Jute"], a: 2, e: "Rabi crops are sown in winter (October to December) and harvested in summer. Wheat is the main rabi crop." },
  { s: "sst", ch: 9, q: "'Slash and burn' farming in Assam, Meghalaya and Mizoram is called:", o: ["Jhumming", "Plantation", "Terrace farming", "Mixed farming"], a: 0, e: "In north-east India, slash and burn farming is called jhumming." },
  { s: "sst", ch: 9, q: "Jute is known as the:", o: ["Black gold", "Golden fibre", "White gold", "Green gold"], a: 1, e: "Jute is called the golden fibre." },
  { s: "sst", ch: 9, q: "The Bhoodan-Gramdan movement was started by:", o: ["Vinoba Bhave", "Sunderlal Bahuguna", "Medha Patkar", "Baba Amte"], a: 0, e: "Vinoba Bhave asked landowners to donate land to the landless." },
  // 10 Minerals and Energy
  { s: "sst", ch: 10, q: "The finest iron ore, with up to 70% iron, is:", o: ["Haematite", "Magnetite", "Limonite", "Siderite"], a: 1, e: "Magnetite has very good magnetic qualities and up to 70% iron." },
  { s: "sst", ch: 10, q: "Aluminium is obtained from:", o: ["Mica", "Bauxite", "Limestone", "Manganese"], a: 1, e: "Bauxite is the ore of aluminium." },
  { s: "sst", ch: 10, q: "The Koderma-Gaya-Hazaribagh belt in Jharkhand is the leading producer of:", o: ["Copper", "Mica", "Coal", "Gold"], a: 1, e: "This belt is India's leading mica-producing area." },
  { s: "sst", ch: 10, q: "Which is the highest-quality coal?", o: ["Lignite", "Peat", "Bituminous", "Anthracite"], a: 3, e: "Anthracite is the hardest and highest-quality coal." },
  // 11 Manufacturing
  { s: "sst", ch: 11, q: "Which is an agro-based industry?", o: ["Iron and steel", "Cotton textiles", "Cement", "Aluminium smelting"], a: 1, e: "Cotton textiles, jute, sugar and edible oil depend on farm raw materials." },
  { s: "sst", ch: 11, q: "Most jute mills in India are located along the:", o: ["Hugli river", "Yamuna river", "Narmada river", "Godavari river"], a: 0, e: "Jute mills are concentrated along the Hugli in West Bengal." },
  { s: "sst", ch: 11, q: "The iron and steel industry is called a basic industry because:", o: ["It is very old", "All other industries depend on it for machinery", "It uses no raw materials", "It is small-scale"], a: 1, e: "Heavy, medium and light industries all depend on iron and steel." },
  { s: "sst", ch: 11, q: "Which city has emerged as the electronics and IT capital of India?", o: ["Kolkata", "Bengaluru", "Kanpur", "Jaipur"], a: 1, e: "Bengaluru is known as the electronic capital of India." },
  // 12 Lifelines
  { s: "sst", ch: 12, q: "The Golden Quadrilateral links:", o: ["Delhi, Kolkata, Chennai and Mumbai", "Delhi, Jaipur, Agra and Lucknow", "Srinagar, Kanyakumari, Silchar and Porbandar", "Mumbai, Pune, Goa and Bengaluru"], a: 0, e: "These super highways link the four metro cities." },
  { s: "sst", ch: 12, q: "National Waterway No. 1 is on the Ganga between Allahabad (Prayagraj) and:", o: ["Patna", "Haldia", "Varanasi", "Kolkata"], a: 1, e: "NW-1 runs 1620 km from Allahabad to Haldia." },
  { s: "sst", ch: 12, q: "Which is an inland riverine port?", o: ["Mumbai", "Kolkata", "Kandla", "Kochi"], a: 1, e: "Kolkata, on the Hugli, is an inland riverine port." },
  { s: "sst", ch: 12, q: "The deepest landlocked and well-protected port in India is:", o: ["Visakhapatnam", "Chennai", "Paradip", "Tuticorin"], a: 0, e: "Visakhapatnam is the deepest landlocked port." },
  // 13 Power Sharing
  { s: "sst", ch: 13, q: "In 1956, Sri Lanka passed an Act recognising which language as the only official language?", o: ["Tamil", "Sinhala", "English", "Hindi"], a: 1, e: "The Act made Sinhala the only official language, a majoritarian step that alienated Sri Lankan Tamils." },
  { s: "sst", ch: 13, q: "In Belgium, the majority community in the country as a whole speaks:", o: ["French", "Dutch", "German", "English"], a: 1, e: "About 59% speak Dutch, 40% French and 1% German." },
  { s: "sst", ch: 13, q: "Power shared among the legislature, executive and judiciary is called:", o: ["Vertical distribution", "Horizontal distribution", "Federal distribution", "Community distribution"], a: 1, e: "Organs at the same level share power horizontally, with checks and balances." },
  { s: "sst", ch: 13, q: "Assertion (A): Power sharing is good for democracy.\nReason (R): It reduces the chance of conflict between social groups.", o: AR, a: 0, e: "This is the prudential reason for power sharing, so R explains A." },
  // 14 Federalism
  { s: "sst", ch: 14, q: "Which subject is in the Union List?", o: ["Police", "Agriculture", "Defence", "Education"], a: 2, e: "Defence, foreign affairs, banking and currency are on the Union List." },
  { s: "sst", ch: 14, q: "Education, forests, marriage and adoption are in the:", o: ["Union List", "State List", "Concurrent List", "Residuary subjects"], a: 2, e: "Both the Union and the States can make laws on Concurrent List subjects." },
  { s: "sst", ch: 14, q: "India, Spain and Belgium are examples of:", o: ["Coming together federations", "Holding together federations", "Unitary governments", "Confederations"], a: 1, e: "In holding together federations, a large country divides power between the centre and states." },
  { s: "sst", ch: 14, q: "The 1992 constitutional amendment on local government reserves at least how many seats for women?", o: ["One-fourth", "One-third", "One-half", "None"], a: 1, e: "At least one-third of positions in local bodies are reserved for women." },
  // 15 Gender, Religion and Caste
  { s: "sst", ch: 15, q: "The idea that women's main job is housework and bringing up children is called:", o: ["Feminism", "Sexual division of labour", "Patriarchy only", "Communalism"], a: 1, e: "Sexual division of labour assigns housework to women even when they also work outside." },
  { s: "sst", ch: 15, q: "Which statement about India's Constitution is correct?", o: ["It has an official religion", "It does not give a special status to any religion", "It bans religion", "It gives the state no power to intervene in religion"], a: 1, e: "India is secular: no official religion, freedom to practise any religion, and the state can act against discrimination." },
  { s: "sst", ch: 15, q: "Using religion to build political unity of one community against others is called:", o: ["Secularism", "Communalism", "Federalism", "Casteism"], a: 1, e: "Communal politics treats religion as the basis of a political community." },
  // 16 Political Parties
  { s: "sst", ch: 16, q: "India has which type of party system?", o: ["One-party", "Two-party", "Multi-party", "No-party"], a: 2, e: "Several parties compete, and coalitions often form governments." },
  { s: "sst", ch: 16, q: "A party is recognised as a national party if it gets at least 6% of votes in Lok Sabha or Assembly elections in four States and wins at least:", o: ["Two Lok Sabha seats", "Four Lok Sabha seats", "Ten Lok Sabha seats", "One seat in each State"], a: 1, e: "That is the Election Commission criterion described in the NCERT book." },
  { s: "sst", ch: 16, q: "The anti-defection law stops elected members from:", o: ["Contesting elections", "Changing parties after being elected", "Forming new parties", "Speaking in Parliament"], a: 1, e: "A member who changes party loses their seat in the legislature." },
  // 17 Outcomes of Democracy
  { s: "sst", ch: 17, q: "Democracy is considered better than other forms because it is:", o: ["Always fast at decisions", "Accountable, responsive and legitimate", "Free of all corruption", "Run by experts only"], a: 1, e: "Democracy produces a government that is accountable to citizens and responsive to their needs." },
  { s: "sst", ch: 17, q: "A common criticism of democracy is that:", o: ["It never allows debate", "Decision-making can be slow", "It ignores elections", "It has no constitution"], a: 1, e: "Because of discussion and negotiation, decisions can take longer, but they are more acceptable." },
  { s: "sst", ch: 17, q: "Assertion (A): Democracy promotes the dignity and freedom of citizens.\nReason (R): Democracy recognises that all individuals are equal.", o: AR, a: 0, e: "Equal status of every citizen is why democracy upholds individual dignity." },
  // 18 Development
  { s: "sst", ch: 18, q: "Per capita income is calculated as:", o: ["Total income of the country × population", "Total income of the country ÷ population", "Total exports ÷ imports", "Income of the richest 10%"], a: 1, e: "Average (per capita) income = national income divided by total population." },
  { s: "sst", ch: 18, q: "The Human Development Report is published by:", o: ["World Bank", "UNDP", "IMF", "WTO"], a: 1, e: "The UNDP compares countries using income, health and education." },
  { s: "sst", ch: 18, q: "Infant mortality rate is the number of children who die before age one per:", o: ["100 live births", "1000 live births", "10,000 people", "1 lakh people"], a: 1, e: "IMR is deaths before age one per 1000 live births in a year." },
  { s: "sst", ch: 18, q: "Development that meets present needs without harming future generations is called:", o: ["Rapid development", "Sustainable development", "Industrial development", "Economic growth"], a: 1, e: "Sustainable development keeps resources for future generations." },
  // 19 Sectors
  { s: "sst", ch: 19, q: "Which activity is in the tertiary sector?", o: ["Farming", "Mining", "Banking", "Manufacturing"], a: 2, e: "Services such as banking, transport and teaching are tertiary." },
  { s: "sst", ch: 19, q: "When more people work in a job than are needed, it is called:", o: ["Seasonal unemployment", "Disguised unemployment", "Open unemployment", "Full employment"], a: 1, e: "Removing the extra workers would not reduce output; common in farming." },
  { s: "sst", ch: 19, q: "MGNREGA 2005 guarantees how many days of work a year to rural households?", o: ["50", "100", "150", "365"], a: 1, e: "It guarantees 100 days of employment, or an unemployment allowance." },
  { s: "sst", ch: 19, q: "GDP is the value of all ______ goods and services produced in a country in a year.", o: ["Intermediate", "Final", "Imported", "Exported only"], a: 1, e: "Only final goods are counted, to avoid counting the same value twice." },
  // 20 Money and Credit
  { s: "sst", ch: 20, q: "Money solves the problem of:", o: ["Inflation", "Double coincidence of wants", "Unemployment", "Taxation"], a: 1, e: "In barter, both sides must want what the other has. Money removes this need." },
  { s: "sst", ch: 20, q: "Who issues currency notes in India on behalf of the central government?", o: ["State Bank of India", "Reserve Bank of India", "Finance Ministry", "NITI Aayog"], a: 1, e: "The RBI issues currency notes." },
  { s: "sst", ch: 20, q: "An asset a borrower pledges as a guarantee to the lender is called:", o: ["Interest", "Collateral", "Deposit", "Dividend"], a: 1, e: "Collateral (land, buildings, gold) can be sold by the lender if the loan is not repaid." },
  { s: "sst", ch: 20, q: "A typical Self Help Group has:", o: ["2 to 5 members", "15 to 20 members", "100 members", "Only bank officers"], a: 1, e: "SHGs usually have 15 to 20 members, mostly women, who pool savings and give small loans." },
  // 21 Globalisation
  { s: "sst", ch: 21, q: "A company that owns or controls production in more than one country is a:", o: ["Cooperative", "Multinational corporation (MNC)", "Public sector unit", "Self Help Group"], a: 1, e: "MNCs set up production where costs are low and markets are near." },
  { s: "sst", ch: 21, q: "A tax on imports is called a:", o: ["Subsidy", "Tariff", "Quota", "Dividend"], a: 1, e: "Tariffs make imported goods costlier." },
  { s: "sst", ch: 21, q: "India began major economic liberalisation in:", o: ["1947", "1971", "1991", "2005"], a: 2, e: "In 1991, India removed many barriers on foreign trade and investment." },
  { s: "sst", ch: 21, q: "The World Trade Organisation aims to:", o: ["Increase tariffs", "Liberalise international trade", "Print world currency", "Fund wars"], a: 1, e: "The WTO sets rules to make international trade freer." },

  // ---------- ENGLISH (Communicative) ----------
  { s: "eng", ch: 1, q: "She ______ in Delhi since 2015.", o: ["lives", "is living", "has been living", "lived"], a: 2, e: "'Since 2015' shows an action continuing to now: present perfect continuous." },
  { s: "eng", ch: 1, q: "By the time we reached the station, the train ______.", o: ["left", "has left", "had left", "was leaving"], a: 2, e: "An action completed before another past action uses the past perfect: had left." },
  { s: "eng", ch: 1, q: "Water ______ at 100 °C.", o: ["boil", "boils", "is boiling", "boiled"], a: 1, e: "Universal truths use the simple present." },
  { s: "eng", ch: 1, q: "Look! It ______.", o: ["rains", "is raining", "has rained", "rained"], a: 1, e: "'Look!' points to an action happening now: present continuous." },
  { s: "eng", ch: 2, q: "You ______ wear a helmet while riding; it is the law.", o: ["might", "must", "could", "would"], a: 1, e: "'Must' shows a strong obligation, such as a legal rule." },
  { s: "eng", ch: 2, q: "______ I come in, sir?", o: ["May", "Must", "Should", "Would"], a: 0, e: "'May' is used to ask permission politely." },
  { s: "eng", ch: 2, q: "He ______ swim when he was five.", o: ["can", "could", "must", "shall"], a: 1, e: "'Could' shows ability in the past." },
  { s: "eng", ch: 2, q: "You look tired. You ______ take some rest.", o: ["should", "can", "would", "might not"], a: 0, e: "'Should' is used to give advice." },
  { s: "eng", ch: 3, q: "Neither the teacher nor the students ______ present.", o: ["was", "were", "is", "has been"], a: 1, e: "With 'neither…nor', the verb agrees with the nearer subject, 'students' (plural)." },
  { s: "eng", ch: 3, q: "Each of the boys ______ a prize.", o: ["get", "gets", "are getting", "have got"], a: 1, e: "'Each' is singular, so it takes a singular verb." },
  { s: "eng", ch: 3, q: "The news ______ good today.", o: ["are", "is", "were", "have been"], a: 1, e: "'News' is uncountable and takes a singular verb." },
  { s: "eng", ch: 3, q: "Bread and butter ______ my favourite breakfast.", o: ["is", "are", "were", "have been"], a: 0, e: "When two nouns form one idea, the verb is singular." },
  { s: "eng", ch: 4, q: "He said, \"I am tired.\" Which is the correct reported speech?", o: ["He said that I am tired.", "He said that he was tired.", "He said that he is being tired.", "He told that he had been tired."], a: 1, e: "Change the pronoun (I → he) and move the tense back (am → was)." },
  { s: "eng", ch: 4, q: "She said to me, \"Please close the door.\" Reported speech:", o: ["She told me please close the door.", "She requested me to close the door.", "She said me to close the door.", "She asked that I closed the door."], a: 1, e: "A polite command becomes 'requested + object + to-infinitive'." },
  { s: "eng", ch: 4, q: "He asked me, \"Where do you live?\" Reported speech:", o: ["He asked me where do I live.", "He asked me where I lived.", "He asked me where did I live.", "He asked me that where I lived."], a: 1, e: "Reported questions use statement word order and no question mark: where I lived." },
  { s: "eng", ch: 4, q: "The teacher said, \"The Earth revolves around the Sun.\" Reported speech:", o: ["The teacher said that the Earth revolved around the Sun.", "The teacher said that the Earth revolves around the Sun.", "The teacher said that the Earth had revolved around the Sun.", "The teacher said that the Earth was revolving around the Sun."], a: 1, e: "A universal truth keeps its present tense in reported speech." },
  { s: "eng", ch: 5, q: "In 'I know that he is honest', the clause 'that he is honest' is a:", o: ["Noun clause", "Relative clause", "Adverb clause", "Main clause"], a: 0, e: "It answers 'know what?' and acts as the object, so it is a noun clause." },
  { s: "eng", ch: 5, q: "In 'The boy who won the race is my cousin', the clause 'who won the race' is a:", o: ["Noun clause", "Relative (adjective) clause", "Adverb clause of time", "Main clause"], a: 1, e: "It describes the noun 'boy', so it is a relative clause." },
  { s: "eng", ch: 5, q: "In 'I will wait until you return', the clause 'until you return' is an adverb clause of:", o: ["Place", "Reason", "Time", "Condition"], a: 2, e: "It tells us when, so it is an adverb clause of time." },
  { s: "eng", ch: 6, q: "He is ______ honest man.", o: ["a", "an", "the", "no article"], a: 1, e: "'Honest' begins with a vowel sound (the h is silent), so we use 'an'." },
  { s: "eng", ch: 6, q: "There is ______ milk in the jug, so we must buy more.", o: ["few", "little", "many", "a few"], a: 1, e: "'Little' (not much) is used with uncountable nouns like milk." },
  { s: "eng", ch: 6, q: "I have ______ friends here, so I never feel lonely.", o: ["much", "many", "little", "a little"], a: 1, e: "'Many' is used with countable plural nouns like friends." },
  { s: "eng", ch: 7, q: "'Two Gentlemen of Verona' was written by:", o: ["Saki", "A. J. Cronin", "Satyajit Ray", "Ruskin Bond"], a: 1, e: "A. J. Cronin wrote this story about Nicola and Jacopo." },
  { s: "eng", ch: 7, q: "In 'Two Gentlemen of Verona', the boys work hard to pay for their sister Lucia's treatment for:", o: ["Typhoid", "Tuberculosis of the spine", "A broken leg", "Malaria"], a: 1, e: "Lucia was in a sanatorium being treated for tuberculosis of the spine." },
  { s: "eng", ch: 7, q: "In 'Mrs Packletide's Tiger' by Saki, Mrs Packletide wanted to shoot a tiger mainly to outdo:", o: ["Miss Mebbin", "Loona Bimberton", "Her husband", "The villagers"], a: 1, e: "She wanted to outshine Loona Bimberton, who had been carried in an aeroplane." },
  { s: "eng", ch: 7, q: "In 'Patol Babu, Film Star' by Satyajit Ray, Patol Babu's role had just one word:", o: ["Help!", "Oh!", "Stop!", "Yes!"], a: 1, e: "He made the single word 'Oh!' meaningful through careful rehearsal." },
  { s: "eng", ch: 8, q: "'The Frog and the Nightingale' was written by:", o: ["Vikram Seth", "Robert Frost", "W. H. Auden", "Rabindranath Tagore"], a: 0, e: "Vikram Seth's poem is set in Bingle Bog." },
  { s: "eng", ch: 8, q: "'Ozymandias' was written by:", o: ["John Keats", "P. B. Shelley", "William Wordsworth", "Lord Byron"], a: 1, e: "Shelley's sonnet shows that the power and pride of rulers do not last." },
  { s: "eng", ch: 8, q: "'Not Marble, nor the Gilded Monuments' is a sonnet by:", o: ["John Milton", "William Shakespeare", "Christina Rossetti", "Alfred Tennyson"], a: 1, e: "In this sonnet, Shakespeare says his verse will outlive marble and gilded monuments." },
  { s: "eng", ch: 8, q: "In 'The Rime of the Ancient Mariner', the Mariner brought a curse on the ship by shooting:", o: ["A seagull", "An albatross", "A dolphin", "A sailor"], a: 1, e: "Killing the albatross, a bird of good omen, brought the curse." },
  { s: "eng", ch: 8, q: "'Snake' is a poem by:", o: ["D. H. Lawrence", "Ted Hughes", "W. B. Yeats", "T. S. Eliot"], a: 0, e: "D. H. Lawrence describes meeting a snake at his water trough." },
  { s: "eng", ch: 9, q: "'The Dear Departed' was written by:", o: ["Stanley Houghton", "George Bernard Shaw", "Oscar Wilde", "J. M. Barrie"], a: 0, e: "Stanley Houghton's play is a comedy about greed in a family." },
  { s: "eng", ch: 9, q: "In 'The Dear Departed', the grandfather whom the family think is dead is:", o: ["Ben Jordan", "Abel Merryweather", "Henry Slater", "John Shorter"], a: 1, e: "Abel Merryweather 'comes back to life' and surprises his greedy daughters." },
  { s: "eng", ch: 9, q: "In 'Julius Caesar', who begins his funeral speech with 'Friends, Romans, countrymen, lend me your ears'?", o: ["Brutus", "Cassius", "Mark Antony", "Octavius"], a: 2, e: "Mark Antony's speech turns the crowd against the conspirators." },

  // ---------- HINDI-B ----------
  { s: "hin", ch: 1, q: "\"सबसे तेज़ दौड़ने वाला लड़का प्रथम आया।\" इसमें 'सबसे तेज़ दौड़ने वाला लड़का' कौन-सा पदबंध है?", o: ["संज्ञा पदबंध", "विशेषण पदबंध", "क्रिया पदबंध", "क्रियाविशेषण पदबंध"], a: 0, e: "पूरा पदबंध 'लड़का' (संज्ञा) का काम कर रहा है और कर्ता है, इसलिए संज्ञा पदबंध।" },
  { s: "hin", ch: 1, q: "\"वह बहुत धीरे-धीरे चलता है।\" इसमें 'बहुत धीरे-धीरे' कौन-सा पदबंध है?", o: ["संज्ञा पदबंध", "विशेषण पदबंध", "क्रियाविशेषण पदबंध", "सर्वनाम पदबंध"], a: 2, e: "यह क्रिया 'चलता है' की विशेषता बताता है, इसलिए क्रियाविशेषण पदबंध।" },
  { s: "hin", ch: 1, q: "\"बच्चा पढ़ता जा रहा है।\" इसमें 'पढ़ता जा रहा है' कौन-सा पदबंध है?", o: ["क्रिया पदबंध", "संज्ञा पदबंध", "विशेषण पदबंध", "क्रियाविशेषण पदबंध"], a: 0, e: "कई क्रिया पद मिलकर एक क्रिया का काम कर रहे हैं, इसलिए क्रिया पदबंध।" },
  { s: "hin", ch: 1, q: "\"गली में रहने वाला बूढ़ा आदमी बीमार है।\" इसमें 'गली में रहने वाला' कौन-सा पदबंध है?", o: ["संज्ञा पदबंध", "विशेषण पदबंध", "क्रिया पदबंध", "क्रियाविशेषण पदबंध"], a: 1, e: "यह 'आदमी' की विशेषता बता रहा है, इसलिए विशेषण पदबंध।" },
  { s: "hin", ch: 2, q: "\"जब वर्षा हुई, तब हम घर में थे।\" रचना के आधार पर यह वाक्य है:", o: ["सरल वाक्य", "संयुक्त वाक्य", "मिश्र वाक्य", "आज्ञावाचक वाक्य"], a: 2, e: "'जब-तब' से एक आश्रित उपवाक्य और एक प्रधान उपवाक्य जुड़े हैं, इसलिए मिश्र वाक्य।" },
  { s: "hin", ch: 2, q: "\"मैं बाज़ार गया और फल लाया।\" रचना के आधार पर यह वाक्य है:", o: ["सरल वाक्य", "संयुक्त वाक्य", "मिश्र वाक्य", "प्रश्नवाचक वाक्य"], a: 1, e: "दो स्वतंत्र उपवाक्य 'और' से जुड़े हैं, इसलिए संयुक्त वाक्य।" },
  { s: "hin", ch: 2, q: "\"वह खाना खाकर सो गया।\" रचना के आधार पर यह वाक्य है:", o: ["सरल वाक्य", "संयुक्त वाक्य", "मिश्र वाक्य", "विस्मयादिबोधक वाक्य"], a: 0, e: "इसमें एक ही मुख्य क्रिया (सो गया) है, इसलिए सरल वाक्य।" },
  { s: "hin", ch: 2, q: "\"वह गरीब है, इसलिए पढ़ नहीं सका।\" रचना के आधार पर यह वाक्य है:", o: ["सरल वाक्य", "संयुक्त वाक्य", "मिश्र वाक्य", "निषेधवाचक वाक्य"], a: 1, e: "'इसलिए' से दो स्वतंत्र उपवाक्य जुड़े हैं, इसलिए संयुक्त वाक्य।" },
  { s: "hin", ch: 3, q: "'राजपुत्र' में कौन-सा समास है?", o: ["द्वंद्व", "तत्पुरुष", "बहुव्रीहि", "अव्ययीभाव"], a: 1, e: "राजा का पुत्र: 'का' विभक्ति का लोप, इसलिए तत्पुरुष समास।" },
  { s: "hin", ch: 3, q: "'नीलकमल' में कौन-सा समास है?", o: ["कर्मधारय", "द्विगु", "द्वंद्व", "बहुव्रीहि"], a: 0, e: "नीला है जो कमल: विशेषण-विशेष्य संबंध, इसलिए कर्मधारय समास।" },
  { s: "hin", ch: 3, q: "'चौराहा' में कौन-सा समास है?", o: ["द्विगु", "तत्पुरुष", "अव्ययीभाव", "कर्मधारय"], a: 0, e: "चार राहों का समूह: पहला पद संख्यावाचक, इसलिए द्विगु समास।" },
  { s: "hin", ch: 3, q: "'यथाशक्ति' में कौन-सा समास है?", o: ["अव्ययीभाव", "द्वंद्व", "द्विगु", "बहुव्रीहि"], a: 0, e: "शक्ति के अनुसार: पहला पद 'यथा' अव्यय है, इसलिए अव्ययीभाव समास।" },
  { s: "hin", ch: 3, q: "'पीतांबर' (पीले हैं वस्त्र जिसके, अर्थात श्रीकृष्ण) में कौन-सा समास है?", o: ["कर्मधारय", "बहुव्रीहि", "तत्पुरुष", "द्वंद्व"], a: 1, e: "दोनों पद मिलकर किसी तीसरे (श्रीकृष्ण) की ओर संकेत करते हैं, इसलिए बहुव्रीहि समास।" },
  { s: "hin", ch: 3, q: "'माता-पिता' में कौन-सा समास है?", o: ["द्वंद्व", "द्विगु", "तत्पुरुष", "अव्ययीभाव"], a: 0, e: "माता और पिता: दोनों पद प्रधान, इसलिए द्वंद्व समास।" },
  { s: "hin", ch: 4, q: "'आँखों का तारा' मुहावरे का अर्थ है:", o: ["बहुत प्यारा", "बहुत दूर", "अंधा होना", "रात में जागना"], a: 0, e: "आँखों का तारा = बहुत प्यारा।" },
  { s: "hin", ch: 4, q: "'नौ दो ग्यारह होना' मुहावरे का अर्थ है:", o: ["गिनती करना", "भाग जाना", "धनी होना", "हिसाब लगाना"], a: 1, e: "नौ दो ग्यारह होना = भाग जाना।" },
  { s: "hin", ch: 4, q: "'दाँत खट्टे करना' मुहावरे का अर्थ है:", o: ["खट्टा खाना", "बुरी तरह हराना", "डर जाना", "दाँत में दर्द होना"], a: 1, e: "दाँत खट्टे करना = बुरी तरह हराना।" },
  { s: "hin", ch: 4, q: "'हाथ पीले करना' मुहावरे का अर्थ है:", o: ["हल्दी लगाना", "बेटी का विवाह करना", "बीमार होना", "मेहनत करना"], a: 1, e: "हाथ पीले करना = (बेटी का) विवाह करना।" },
  { s: "hin", ch: 5, q: "'बड़े भाई साहब' कहानी के लेखक हैं:", o: ["प्रेमचंद", "जयशंकर प्रसाद", "हबीब तनवीर", "रवींद्र केलेकर"], a: 0, e: "'बड़े भाई साहब' प्रेमचंद की कहानी है।" },
  { s: "hin", ch: 5, q: "'तताँरा-वामीरो कथा' के लेखक हैं:", o: ["निदा फ़ाज़ली", "लीलाधर मंडलोई", "प्रहलाद अग्रवाल", "सीताराम सेकसरिया"], a: 1, e: "लीलाधर मंडलोई ने निकोबार की इस लोककथा को लिखा है।" },
  { s: "hin", ch: 5, q: "'डायरी का एक पन्ना' किसकी डायरी का अंश है?", o: ["सीताराम सेकसरिया", "महादेव देसाई", "प्रेमचंद", "यशपाल"], a: 0, e: "यह सीताराम सेकसरिया की डायरी का अंश है, जिसमें 26 जनवरी 1931 के कलकत्ता का वर्णन है।" },
  { s: "hin", ch: 5, q: "'तीसरी कसम के शिल्पकार शैलेंद्र' पाठ के लेखक हैं:", o: ["प्रहलाद अग्रवाल", "हबीब तनवीर", "गुरदयाल सिंह", "मिथिलेश्वर"], a: 0, e: "प्रहलाद अग्रवाल ने गीतकार शैलेंद्र और उनकी फ़िल्म 'तीसरी कसम' पर यह पाठ लिखा।" },
  { s: "hin", ch: 6, q: "'मनुष्यता' कविता के कवि हैं:", o: ["सुमित्रानंदन पंत", "मैथिलीशरण गुप्त", "कबीर", "वीरेन डंगवाल"], a: 1, e: "'मनुष्यता' मैथिलीशरण गुप्त की कविता है, जो परोपकार का संदेश देती है।" },
  { s: "hin", ch: 6, q: "'पर्वत प्रदेश में पावस' कविता के कवि हैं:", o: ["सुमित्रानंदन पंत", "रवींद्रनाथ ठाकुर", "कैफ़ी आज़मी", "मीरा"], a: 0, e: "सुमित्रानंदन पंत ने पहाड़ों में वर्षा ऋतु का सुंदर वर्णन किया है।" },
  { s: "hin", ch: 6, q: "मीरा के पदों में मीरा अपने आराध्य के रूप में किसकी भक्ति करती हैं?", o: ["श्रीराम", "श्रीकृष्ण", "शिव", "निराकार ब्रह्म"], a: 1, e: "मीरा श्रीकृष्ण (गिरधर गोपाल) की भक्त थीं।" },
  { s: "hin", ch: 7, q: "'हरिहर काका' कहानी के लेखक हैं:", o: ["मिथिलेश्वर", "गुरदयाल सिंह", "राही मासूम रज़ा", "प्रेमचंद"], a: 0, e: "'हरिहर काका' मिथिलेश्वर की कहानी है।" },
  { s: "hin", ch: 7, q: "'टोपी शुक्ला' के लेखक हैं:", o: ["राही मासूम रज़ा", "मिथिलेश्वर", "निदा फ़ाज़ली", "हबीब तनवीर"], a: 0, e: "'टोपी शुक्ला' राही मासूम रज़ा के उपन्यास का अंश है।" },
  { s: "hin", ch: 7, q: "'सपनों के-से दिन' के लेखक हैं:", o: ["गुरदयाल सिंह", "प्रहलाद अग्रवाल", "लीलाधर मंडलोई", "मिथिलेश्वर"], a: 0, e: "गुरदयाल सिंह ने अपने बचपन और स्कूल के दिनों की यादें लिखी हैं।" },

  // ---------- ARTIFICIAL INTELLIGENCE ----------
  { s: "ai", ch: 1, q: "What is the first stage of the AI Project Cycle?", o: ["Data Acquisition", "Problem Scoping", "Modelling", "Evaluation"], a: 1, e: "The cycle starts with Problem Scoping: understanding the problem before collecting data." },
  { s: "ai", ch: 1, q: "The 4Ws Problem Canvas asks:", o: ["Who, What, Where, Why", "Who, When, Which, Way", "What, When, Where, Will", "Why, Which, Who, Work"], a: 0, e: "Who is affected, What the problem is, Where it occurs, and Why solving it matters." },
  { s: "ai", ch: 1, q: "Which is the correct order of the AI Project Cycle?", o: ["Modelling → Problem Scoping → Data Acquisition → Evaluation", "Problem Scoping → Data Acquisition → Data Exploration → Modelling → Evaluation → Deployment", "Data Exploration → Evaluation → Modelling → Problem Scoping", "Deployment → Modelling → Evaluation → Data Acquisition"], a: 1, e: "Scope the problem, get data, explore it, build a model, evaluate it, then deploy it." },
  { s: "ai", ch: 1, q: "If an AI hiring tool is trained mostly on data from one group, it may treat others unfairly. This ethical problem is called:", o: ["Overfitting", "Bias", "Tokenisation", "Deployment"], a: 1, e: "Unbalanced training data leads to biased, unfair results." },
  { s: "ai", ch: 2, q: "Learning from labelled data (inputs with known answers) is called:", o: ["Supervised learning", "Unsupervised learning", "Reinforcement learning", "Rule-based learning"], a: 0, e: "In supervised learning, the model learns from examples whose correct labels are given." },
  { s: "ai", ch: 2, q: "Grouping customers by similar buying habits, without any labels, is an example of:", o: ["Classification", "Regression", "Clustering", "Reinforcement"], a: 2, e: "Clustering is unsupervised: it finds natural groups in unlabelled data." },
  { s: "ai", ch: 2, q: "Predicting tomorrow's temperature (a number) is a ______ problem.", o: ["Classification", "Regression", "Clustering", "Dimensionality reduction"], a: 1, e: "Regression predicts a continuous value; classification predicts a category." },
  { s: "ai", ch: 2, q: "A model that learns by getting rewards for good actions and penalties for bad ones uses:", o: ["Supervised learning", "Unsupervised learning", "Reinforcement learning", "Data exploration"], a: 2, e: "Reinforcement learning learns by trial, error and rewards, like training a game-playing agent." },
  { s: "ai", ch: 2, q: "The three types of layers in a basic neural network are:", o: ["Input, hidden and output", "Top, middle and bottom", "Data, model and result", "Pixel, channel and frame"], a: 0, e: "Data enters the input layer, is processed in hidden layers, and the output layer gives the result." },
  { s: "ai", ch: 3, q: "A model gives TP = 50, TN = 30, FP = 10 and FN = 10. Its accuracy is:", o: ["50%", "60%", "80%", "90%"], a: 2, e: "Accuracy = (TP + TN) / total = (50 + 30) / 100 = 80%." },
  { s: "ai", ch: 3, q: "Precision is calculated as:", o: ["TP / (TP + FN)", "TP / (TP + FP)", "(TP + TN) / Total", "FP / (FP + TN)"], a: 1, e: "Precision = TP / (TP + FP): of everything predicted positive, how much was right." },
  { s: "ai", ch: 3, q: "Recall is calculated as:", o: ["TP / (TP + FN)", "TP / (TP + FP)", "TN / (TN + FP)", "(TP + TN) / Total"], a: 0, e: "Recall = TP / (TP + FN): of all actual positives, how many were found." },
  { s: "ai", ch: 3, q: "The F1 score combines:", o: ["Accuracy and error", "Precision and recall", "TP and TN only", "Training and testing data"], a: 1, e: "F1 = 2 × Precision × Recall / (Precision + Recall)." },
  { s: "ai", ch: 3, q: "In a disease-detection model, which error is usually most dangerous?", o: ["True positive", "True negative", "False negative", "False positive"], a: 2, e: "A false negative tells a sick person they are healthy, so treatment is missed." },
  { s: "ai", ch: 3, q: "Why should a model be evaluated on test data rather than its training data?", o: ["Training data is too small", "To check it works on new data and has not just memorised (overfitted)", "Test data is always labelled wrongly", "It makes the model faster"], a: 1, e: "A model can score perfectly on data it has seen. New data shows real performance." },
  { s: "ai", ch: 4, q: "The mean of 2, 4, 6 and 8 is:", o: ["4", "5", "6", "20"], a: 1, e: "Mean = (2 + 4 + 6 + 8) / 4 = 20 / 4 = 5." },
  { s: "ai", ch: 4, q: "The median of 3, 9 and 7 is:", o: ["3", "7", "9", "6.3"], a: 1, e: "Arrange in order (3, 7, 9); the middle value is 7." },
  { s: "ai", ch: 4, q: "The value that appears most often in a data set is the:", o: ["Mean", "Median", "Mode", "Range"], a: 2, e: "Mode = most frequent value." },
  { s: "ai", ch: 4, q: "Which is a no-code tool used in CBSE AI classes to explore data and build models visually?", o: ["Orange Data Mining", "Microsoft Paint", "Notepad", "Calculator"], a: 0, e: "Orange lets students build data workflows by dragging widgets, without writing code." },
  { s: "ai", ch: 5, q: "The smallest unit of a digital image is a:", o: ["Byte", "Pixel", "Frame", "Channel"], a: 1, e: "A pixel (picture element) is one tiny dot of colour." },
  { s: "ai", ch: 5, q: "In an 8-bit image, each colour value of a pixel ranges from:", o: ["0 to 100", "0 to 255", "1 to 256", "−128 to 128"], a: 1, e: "8 bits give 256 values: 0 (none) to 255 (full)." },
  { s: "ai", ch: 5, q: "In RGB, pure white is represented as:", o: ["(0, 0, 0)", "(255, 255, 255)", "(255, 0, 0)", "(128, 128, 128)"], a: 1, e: "All three colours at full strength make white; (0, 0, 0) is black." },
  { s: "ai", ch: 5, q: "How many pixels does an image of resolution 1280 × 720 have?", o: ["2,000", "92,160", "921,600", "9,216,000"], a: 2, e: "1280 × 720 = 921,600 pixels." },
  { s: "ai", ch: 5, q: "Finding where each object is in an image and drawing a box around it is called:", o: ["Image classification", "Object detection", "Tokenisation", "Clustering"], a: 1, e: "Classification says what the image shows; object detection also locates each object." },
  { s: "ai", ch: 6, q: "Breaking a sentence into individual words is called:", o: ["Stemming", "Tokenisation", "Lemmatisation", "Segmentation of images"], a: 1, e: "Each word or symbol becomes a token." },
  { s: "ai", ch: 6, q: "Words like 'the', 'is' and 'and', which are often removed in NLP, are called:", o: ["Keywords", "Stopwords", "Tokens", "Lemmas"], a: 1, e: "Stopwords occur very often but add little meaning, so they are usually removed." },
  { s: "ai", ch: 6, q: "How is lemmatisation different from stemming?", o: ["Lemmatisation always gives a meaningful dictionary word", "Stemming always gives a meaningful word", "They are exactly the same", "Lemmatisation removes all vowels"], a: 0, e: "Stemming may give non-words ('studies' → 'studi'); lemmatisation gives the real root ('study')." },
  { s: "ai", ch: 6, q: "In TF-IDF, a word that appears in almost every document gets:", o: ["A very high value", "A low value", "Exactly 1", "A negative value always"], a: 1, e: "Its inverse document frequency is low, so it is treated as less important." },
  { s: "ai", ch: 6, q: "A chatbot that follows a fixed script and can't handle unexpected questions is a:", o: ["Smart-bot", "Script-bot", "Neural bot", "Vision bot"], a: 1, e: "Script-bots follow predefined paths; smart-bots use AI to handle varied questions." },
  { s: "ai", ch: 6, q: "Identifying whether a product review is positive or negative is called:", o: ["Sentiment analysis", "Object detection", "Regression", "Image classification"], a: 0, e: "Sentiment analysis finds the emotion or opinion in text." },
  { s: "ai", ch: 7, q: "A SMART goal is Specific, Measurable, Achievable, Realistic (or Relevant) and:", o: ["Simple", "Time-bound", "Technical", "Tested"], a: 1, e: "A SMART goal has a clear deadline: time-bound." },
  { s: "ai", ch: 7, q: "Which is an example of a green skill?", o: ["Reducing waste and saving energy at work", "Typing quickly", "Public speaking", "Using a spreadsheet"], a: 0, e: "Green skills help protect the environment, for example by reducing, reusing and recycling." },
  { s: "ai", ch: 7, q: "Which of these is an example of non-verbal communication?", o: ["Writing an email", "Making eye contact", "Giving a speech", "Sending a text message"], a: 1, e: "Non-verbal communication uses gestures, posture, facial expressions and eye contact." }
);
