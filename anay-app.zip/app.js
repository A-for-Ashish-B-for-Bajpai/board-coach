// Board Coach v0.1 — a personal CBSE Class 10 study app. All data stays on this phone.
"use strict";

// ---------- storage ----------
const KEY = "boardcoach.v1";
const DEFAULT_STATE = {
  name: "Anay",
  examDate: "2027-02-17", // first board exam; change in Settings once the date sheet is out
  done: {},          // "sci-1": true
  stats: {},         // question id -> {r: right count, w: wrong count}
  mistakes: [],      // question ids answered wrong and not yet fixed
  studyDays: [],     // "2026-11-17"
  mocks: [],         // {kind:"mini"|"board", s, score, total, date}
  focusEnd: null,    // timestamp when the focus or break timer ends
  focusMode: null,   // "focus" | "break"
  boardMock: null,   // {paper: index, end: timestamp}
  lastTab: "today"
};
let state = load();
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return Object.assign({}, DEFAULT_STATE, JSON.parse(raw));
  } catch (e) { /* storage blocked: run without saving */ }
  return JSON.parse(JSON.stringify(DEFAULT_STATE));
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
}

// ---------- helpers ----------
const $ = (sel) => document.querySelector(sel);
const app = $("#app");
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const SUBJ = Object.fromEntries(SUBJECTS.map((x) => [x.k, x.n]));
function todayStr(d = new Date()) {
  const z = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}
function daysBetween(a, b) { return Math.round((Date.parse(b) - Date.parse(a)) / 864e5); }
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("show"), 2200);
}
function markStudied() {
  const t = todayStr();
  if (!state.studyDays.includes(t)) { state.studyDays.push(t); save(); }
}

// Give every question a stable id: subject-chapter-position.
const counters = {};
QUESTIONS.forEach((q) => {
  const k = q.s + "-" + q.ch;
  counters[k] = (counters[k] || 0) + 1;
  q.id = k + "-" + counters[k];
});
const byId = Object.fromEntries(QUESTIONS.map((q) => [q.id, q]));
const chapterQs = (s, ch) => QUESTIONS.filter((q) => q.s === s && q.ch === ch);
function chapterAccuracy(s, ch) {
  let r = 0, w = 0;
  chapterQs(s, ch).forEach((q) => { const st = state.stats[q.id]; if (st) { r += st.r; w += st.w; } });
  return r + w ? Math.round((100 * r) / (r + w)) : null;
}

// ---------- study plan ----------
function allChapters() {
  const list = [];
  const max = Math.max(...SUBJECTS.map((x) => CHAPTERS[x.k].length));
  for (let i = 0; i < max; i++) SUBJECTS.forEach((x) => { if (i < CHAPTERS[x.k].length) list.push({ s: x.k, ch: i + 1 }); });
  return list;
}
function todaysChapter() {
  // Rotate through the subjects day by day; pick the next chapter not yet marked done.
  const dayNum = Math.floor(Date.parse(todayStr()) / 864e5);
  const keys = SUBJECTS.map((x) => x.k);
  const start = dayNum % keys.length;
  const order = keys.slice(start).concat(keys.slice(0, start));
  for (const s of order) {
    for (let i = 1; i <= CHAPTERS[s].length; i++) if (!state.done[s + "-" + i]) return { s, ch: i, mode: "learn" };
  }
  // Everything done: revise the weakest chapter.
  let worst = null;
  allChapters().forEach((c) => {
    const acc = chapterAccuracy(c.s, c.ch);
    const score = acc === null ? -1 : acc;
    if (!worst || score < worst.score) worst = { ...c, score };
  });
  return { s: worst.s, ch: worst.ch, mode: "revise" };
}
function paceText() {
  const left = allChapters().filter((c) => !state.done[c.s + "-" + c.ch]).length;
  const days = daysBetween(todayStr(), state.examDate);
  const firstPassDays = days - 45; // keep the last 45 days for revision and mock papers
  if (days < 0) return "Exams are over. Well done for getting through them.";
  if (left === 0) return `All chapters done. ${days} days to go: mix revision with mock papers.`;
  if (firstPassDays <= 0) return `${days} days to go. Focus on revision, mistakes and mock papers.`;
  const perWeek = Math.ceil((left / firstPassDays) * 7);
  return `${left} chapters left. Finish them in the next ${firstPassDays} days (about ${perWeek} a week), then keep the last 45 days for revision.`;
}

// ---------- navigation ----------
let view = { tab: state.lastTab || "today" };
document.querySelectorAll("#tabs button").forEach((b) =>
  b.addEventListener("click", () => { go({ tab: b.dataset.tab }); })
);
$("#settingsBtn").addEventListener("click", () => go({ tab: view.tab, screen: "settings" }));
function go(v) {
  if (quiz && quiz.timed && !quiz.finished && v.screen !== "quiz") {
    if (!confirmLeave()) return;
  }
  if (!v.screen || v.screen !== "quiz") quiz = null;
  view = v;
  if (!v.screen) { state.lastTab = v.tab; save(); }
  render();
  window.scrollTo(0, 0);
}
let leaveArmed = 0;
function confirmLeave() {
  // Two taps within 3 seconds to leave a running mock, without a browser dialog.
  if (Date.now() - leaveArmed < 3000) return true;
  leaveArmed = Date.now();
  toast("Mock in progress. Tap again to leave it.");
  return false;
}
function render() {
  document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === view.tab));
  if (view.screen === "quiz") return renderQuiz();
  if (view.screen === "chapter") return renderChapter(view.s, view.ch);
  if (view.screen === "settings") return renderSettings();
  if (view.screen === "board") return renderBoardMock();
  ({ today: renderToday, chapters: renderChapters, mocks: renderMocks, mistakes: renderMistakes }[view.tab] || renderToday)();
}

// ---------- Today ----------
function weekDots() {
  const d = new Date(); const day = (d.getDay() + 6) % 7; // Monday = 0
  const monday = new Date(d); monday.setDate(d.getDate() - day);
  let html = "", count = 0;
  for (let i = 0; i < 7; i++) {
    const x = new Date(monday); x.setDate(monday.getDate() + i);
    const on = state.studyDays.includes(todayStr(x)); if (on) count++;
    html += `<span class="dot ${on ? "on" : ""}" title="${todayStr(x)}"></span>`;
  }
  return { html, count };
}
function renderToday() {
  const t = todaysChapter();
  const name = CHAPTERS[t.s][t.ch - 1];
  const days = daysBetween(todayStr(), state.examDate);
  const dots = weekDots();
  const hour = new Date().getHours();
  const hello = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const acc = chapterAccuracy(t.s, t.ch);
  app.innerHTML = `
    <div class="topline">
      <div><h2>${hello}, ${esc(state.name)}</h2>
      <div class="muted small">Studied ${dots.count} of 7 days this week</div>
      <div class="dots">${dots.html}</div></div>
      <div style="text-align:right"><div class="big">${Math.max(days, 0)}</div><div class="muted small">days to boards</div></div>
    </div>
    <div class="card hero">
      <span class="tag ${t.s}">${SUBJ[t.s]}</span>
      <h2 style="margin-top:8px">${t.mode === "learn" ? "Today" : "Revise today"}: ${esc(name)}</h2>
      <p class="muted small" style="margin:4px 0 0">${t.mode === "learn"
        ? "About 25 minutes. Read the chapter in your textbook, then practise."
        : `Your weakest chapter${acc !== null ? ` (${acc}% correct so far)` : ""}. Practise it again.`}</p>
      <button class="btn btn-primary" style="margin-top:12px" id="startPractice">Start practice</button>
      <div class="btn-row">
        ${NCERT_BOOKS[t.s] ? `<a class="btn btn-ghost" href="${NCERT_BOOKS[t.s]}" target="_blank" rel="noopener">Open NCERT book</a>` : ""}
        ${t.mode === "learn" ? `<button class="btn btn-ghost" id="markDone">Mark done</button>` : ""}
      </div>
    </div>
    <div class="chips">
      ${state.mistakes.length ? `<button class="chip" id="fixMistakes">Fix ${state.mistakes.length} mistake${state.mistakes.length > 1 ? "s" : ""}</button>` : ""}
      <button class="chip" id="focus">25-minute focus timer</button>
      <button class="chip" id="mini">Quick mock (20 questions)</button>
    </div>
    <div class="card"><h3>Pace</h3><p class="muted small" style="margin:0">${esc(paceText())}</p></div>`;
  $("#startPractice").onclick = () => startQuiz({ title: name, qs: shuffle(chapterQs(t.s, t.ch)).slice(0, 10), mode: "practice" });
  if ($("#markDone")) $("#markDone").onclick = () => { state.done[t.s + "-" + t.ch] = true; markStudied(); save(); toast("Chapter marked done"); render(); };
  if ($("#fixMistakes")) $("#fixMistakes").onclick = startMistakeQuiz;
  $("#focus").onclick = startFocus;
  $("#mini").onclick = () => go({ tab: "mocks" });
}

// ---------- Chapters ----------
let chapterSubject = "sci";
function renderChapters() {
  const list = CHAPTERS[chapterSubject];
  const doneCount = list.filter((_, i) => state.done[chapterSubject + "-" + (i + 1)]).length;
  app.innerHTML = `
    <h2>Chapters</h2>
    <div class="seg scroll">${SUBJECTS.map((x) => `<button data-s="${x.k}" class="${chapterSubject === x.k ? "on" : ""}">${x.n}</button>`).join("")}</div>
    <div class="muted small">${doneCount} of ${list.length} done</div>
    <div class="bar"><i style="width:${(100 * doneCount) / list.length}%"></i></div>
    <div class="card">${list.map((n, i) => {
      const k = chapterSubject + "-" + (i + 1); const acc = chapterAccuracy(chapterSubject, i + 1);
      return `<div class="row" data-ch="${i + 1}">
        <span class="check ${state.done[k] ? "on" : ""}" data-toggle="${i + 1}" role="checkbox" aria-checked="${!!state.done[k]}" aria-label="Mark chapter done">${state.done[k] ? "✓" : ""}</span>
        <div class="grow"><div>${i + 1}. ${esc(n)}</div><div class="muted small">${chapterQs(chapterSubject, i + 1).length} questions${acc !== null ? ` · ${acc}% correct` : ""}</div></div>
        <span class="muted">›</span></div>`;
    }).join("")}</div>`;
  app.querySelectorAll(".seg button").forEach((b) => (b.onclick = () => { chapterSubject = b.dataset.s; render(); }));
  app.querySelectorAll(".row").forEach((r) => (r.onclick = (e) => {
    const tog = e.target.closest("[data-toggle]");
    if (tog) { const k = chapterSubject + "-" + tog.dataset.toggle; state.done[k] = !state.done[k]; save(); render(); return; }
    go({ tab: "chapters", screen: "chapter", s: chapterSubject, ch: +r.dataset.ch });
  }));
}
function renderChapter(s, ch) {
  const name = CHAPTERS[s][ch - 1]; const k = s + "-" + ch;
  const qs = chapterQs(s, ch); const acc = chapterAccuracy(s, ch);
  const wrongHere = state.mistakes.filter((id) => id.startsWith(k + "-")).length;
  app.innerHTML = `
    <button class="chip" id="back">‹ Back</button>
    <div class="card hero" style="margin-top:12px">
      <span class="tag ${s}">${SUBJ[s]} · Chapter ${ch}</span>
      <h2 style="margin-top:8px">${esc(name)}</h2>
      <p class="muted small" style="margin:0">${qs.length} questions${acc !== null ? ` · ${acc}% correct so far` : ""}${wrongHere ? ` · ${wrongHere} to fix` : ""}</p>
      <button class="btn btn-primary" style="margin-top:12px" id="practise">Practise this chapter</button>
      <div class="btn-row">
        ${NCERT_BOOKS[s] ? `<a class="btn btn-ghost" href="${NCERT_BOOKS[s]}" target="_blank" rel="noopener">NCERT book</a>` : ""}
        <button class="btn btn-ghost" id="done">${state.done[k] ? "Mark not done" : "Mark done"}</button>
      </div>
    </div>`;
  $("#back").onclick = () => go({ tab: "chapters" });
  $("#practise").onclick = () => startQuiz({ title: name, qs: shuffle(qs), mode: "practice" });
  $("#done").onclick = () => { state.done[k] = !state.done[k]; if (state.done[k]) markStudied(); save(); render(); };
}

// ---------- quiz engine ----------
let quiz = null;
function startQuiz(opts) {
  if (!opts.qs.length) { toast("No questions here yet"); return; }
  // Shuffle answer options so the right answer isn't always in the same place.
  // Assertion-reason options keep their standard order.
  opts.qs = opts.qs.map((q) => {
    if (q.o === AR) return q;
    const order = shuffle([0, 1, 2, 3]);
    return Object.assign({}, q, { o: order.map((k) => q.o[k]), a: order.indexOf(q.a) });
  });
  quiz =Object.assign({ i: 0, answers: [], timed: false, finished: false, startedAt: Date.now() }, opts);
  view = { tab: view.tab, screen: "quiz" };
  render(); window.scrollTo(0, 0);
}
function startMistakeQuiz() {
  const qs = shuffle(state.mistakes.map((id) => byId[id]).filter(Boolean));
  startQuiz({ title: "Fix my mistakes", qs, mode: "mistakes" });
}
function record(q, right) {
  const st = state.stats[q.id] || { r: 0, w: 0 };
  right ? st.r++ : st.w++;
  state.stats[q.id] = st;
  if (!right && !state.mistakes.includes(q.id)) state.mistakes.push(q.id);
  if (right && quiz.mode === "mistakes") state.mistakes = state.mistakes.filter((x) => x !== q.id);
  markStudied(); save();
}
let tick = null;
function renderQuiz() {
  clearInterval(tick);
  if (quiz.finished) return renderResults();
  const q = quiz.qs[quiz.i]; const ans = quiz.answers[quiz.i];
  const showFeedback = !quiz.timed && ans !== undefined;
  const timeLeft = quiz.timed ? Math.max(0, quiz.endAt - Date.now()) : 0;
  app.innerHTML = `
    <div class="topline">
      <button class="chip" id="quit">‹ ${quiz.timed ? "Leave" : "Stop"}</button>
      <span class="muted small">${quiz.i + 1} / ${quiz.qs.length}</span>
      ${quiz.timed ? `<span class="chip" id="qclock" aria-live="off">${fmt(timeLeft)}</span>` : `<span></span>`}
    </div>
    <div class="bar"><i style="width:${(100 * quiz.i) / quiz.qs.length}%"></i></div>
    <div class="card">
      <span class="tag ${q.s}">${SUBJ[q.s]} · Ch ${q.ch}</span>
      <div class="qtext">${esc(q.q)}</div>
      ${q.o.map((o, j) => {
        let cls = "opt";
        if (showFeedback) { if (j === q.a) cls += " right"; else if (j === ans) cls += " wrong"; }
        else if (ans === j) cls += " sel";
        return `<button class="${cls}" data-j="${j}" ${showFeedback ? "disabled" : ""}>${"ABCD"[j]}. ${esc(o)}</button>`;
      }).join("")}
      ${showFeedback ? `<div class="explain ${ans === q.a ? "good" : "bad"}"><strong>${ans === q.a ? "Correct." : "Not quite. Answer: " + "ABCD"[q.a] + "."}</strong> ${esc(q.e)}</div>` : ""}
    </div>
    ${quiz.timed
      ? `<div class="btn-row"><button class="btn btn-ghost" id="prev" ${quiz.i === 0 ? "disabled" : ""}>Previous</button><button class="btn btn-primary" id="next">${quiz.i === quiz.qs.length - 1 ? "Finish" : "Next"}</button></div>`
      : showFeedback ? `<button class="btn btn-primary" id="next">${quiz.i === quiz.qs.length - 1 ? "See results" : "Next question"}</button>` : ""}`;
  $("#quit").onclick = () => {
    if (quiz.timed && !confirmLeave()) return;
    if (quiz.answers.length && !quiz.timed) { quiz.finished = true; render(); } else go({ tab: view.tab });
  };
  app.querySelectorAll(".opt").forEach((b) => (b.onclick = () => {
    const j = +b.dataset.j;
    if (quiz.timed) { quiz.answers[quiz.i] = j; render(); return; }
    quiz.answers[quiz.i] = j; record(q, j === q.a); render();
  }));
  if ($("#next")) $("#next").onclick = () => {
    if (quiz.i < quiz.qs.length - 1) { quiz.i++; render(); window.scrollTo(0, 0); }
    else finishQuiz();
  };
  if ($("#prev")) $("#prev").onclick = () => { if (quiz.i > 0) { quiz.i--; render(); } };
  if (quiz.timed) tick = setInterval(() => {
    const left = quiz.endAt - Date.now();
    if (left <= 0) { clearInterval(tick); toast("Time is up"); finishQuiz(); return; }
    const c = $("#qclock"); if (c) c.textContent = fmt(left);
  }, 1000);
}
function finishQuiz() {
  clearInterval(tick);
  if (quiz.timed) {
    quiz.qs.forEach((q, i) => { if (quiz.answers[i] !== undefined) record(q, quiz.answers[i] === q.a); else record(q, false); });
    const score = quiz.qs.filter((q, i) => quiz.answers[i] === q.a).length;
    state.mocks.push({ kind: "mini", s: quiz.s, score, total: quiz.qs.length, date: todayStr() }); save();
  }
  quiz.finished = true; render(); window.scrollTo(0, 0);
}
function renderResults() {
  const right = quiz.qs.filter((q, i) => quiz.answers[i] === q.a).length;
  const answered = quiz.timed ? quiz.qs.length : quiz.answers.filter((a) => a !== undefined).length;
  const pct = answered ? Math.round((100 * right) / answered) : 0;
  const msg = pct >= 80 ? "Excellent work." : pct >= 60 ? "Good progress. Fix the misses below." : "Every mistake you fix now is a mark saved later.";
  app.innerHTML = `
    <div class="card hero" style="text-align:center">
      <div class="muted small">${esc(quiz.title)}</div>
      <div class="big" style="margin:8px 0">${right} / ${answered}</div>
      <div>${msg}</div>
    </div>
    ${quiz.timed ? `<h3>Review</h3>${quiz.qs.map((q, i) => {
      const a = quiz.answers[i];
      return `<div class="card"><div class="small muted">Q${i + 1} · ${SUBJ[q.s]} Ch ${q.ch}</div><div style="white-space:pre-line">${esc(q.q)}</div>
        <div class="explain ${a === q.a ? "good" : "bad"}"><strong>${a === q.a ? "Correct" : a === undefined ? "Skipped" : "You chose " + "ABCD"[a]}.</strong> Answer: ${"ABCD"[q.a]}. ${esc(q.o[q.a])}. ${esc(q.e)}</div></div>`;
    }).join("")}` : ""}
    <button class="btn btn-primary" id="doneBtn">Done</button>`;
  $("#doneBtn").onclick = () => go({ tab: view.tab });
}
function fmt(ms) {
  const s = Math.ceil(ms / 1000); const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); const sec = s % 60;
  const z = (n) => String(n).padStart(2, "0");
  return h ? `${h}:${z(m)}:${z(sec)}` : `${z(m)}:${z(sec)}`;
}

// ---------- Mocks ----------
function renderMocks() {
  const recent = state.mocks.slice(-8).reverse();
  app.innerHTML = `
    <h2>Mock papers</h2>
    <div class="card">
      <h3>Quick mock</h3>
      <p class="muted small" style="margin:0 0 8px">20 questions from across the subject, 30 minutes, answers shown at the end.</p>
      <div class="grid">${SUBJECTS.map((x) => `<button class="btn btn-primary" data-mini="${x.k}">${x.n}</button>`).join("")}</div>
    </div>
    <div class="card">
      <h3>Full board mock (official CBSE sample papers)</h3>
      <p class="muted small" style="margin:0 0 8px">Write on paper like the real exam (usually 3 hours, 80 marks). Open the paper, start the timer, then mark it yourself with the official marking scheme from the <a href="${SQP_PAGE}" target="_blank" rel="noopener">CBSE sample paper page</a>.</p>
      ${SAMPLE_PAPERS.map((p, i) => `<div class="row" data-board="${i}"><span class="tag ${p.s}">${SUBJ[p.s]}</span><div class="grow">${esc(p.title)}</div><span class="muted">›</span></div>`).join("")}
    </div>
    <div class="card"><h3>Your scores</h3>${recent.length ? recent.map((m) =>
      `<div class="row" style="cursor:default"><span class="tag ${m.s}">${SUBJ[m.s]}</span><div class="grow">${m.kind === "mini" ? "Quick mock" : "Board mock"} · ${m.date}</div><strong>${m.score} / ${m.total}</strong></div>`).join("")
      : `<p class="muted small" style="margin:0">No mocks yet. Try a quick mock first.</p>`}</div>`;
  app.querySelectorAll("[data-mini]").forEach((b) => (b.onclick = () => {
    const s = b.dataset.mini;
    startQuiz({ title: `${SUBJ[s]} quick mock`, qs: shuffle(QUESTIONS.filter((q) => q.s === s)).slice(0, 20), mode: "mock", timed: true, s, endAt: Date.now() + 30 * 60000 });
  }));
  app.querySelectorAll("[data-board]").forEach((r) => (r.onclick = () => go({ tab: "mocks", screen: "board", paper: +r.dataset.board })));
}
function renderBoardMock() {
  clearInterval(tick);
  const running = state.boardMock && state.boardMock.paper === view.paper ? state.boardMock : null;
  const p = SAMPLE_PAPERS[view.paper];
  const left = running ? running.end - Date.now() : p.minutes * 60000;
  app.innerHTML = `
    <button class="chip" id="back">‹ Back</button>
    <div class="card hero" style="margin-top:12px;text-align:center">
      <span class="tag ${p.s}">${SUBJ[p.s]}</span>
      <h2 style="margin-top:8px">${esc(p.title)}</h2>
      <div class="clock" id="bclock">${fmt(Math.max(0, left))}</div>
      ${running ? `<button class="btn btn-ghost" id="stop">Stop timer</button>` : `<button class="btn btn-primary" id="start">Start ${p.minutes / 60}-hour timer</button>`}
      <a class="btn btn-ghost" style="margin-top:8px" href="${p.url}" target="_blank" rel="noopener">Open question paper</a>
      <a class="btn btn-ghost" style="margin-top:8px" href="${p.ms || SQP_PAGE}" target="_blank" rel="noopener">Marking scheme</a>
      <p class="muted small">Tip: download the PDF once while online, so it opens offline during the mock.</p>
    </div>
    <div class="card">
      <h3>After marking, save your score</h3>
      <label for="score">Marks out of ${p.marks}</label>
      <input id="score" type="number" inputmode="numeric" min="0" max="${p.marks}" placeholder="e.g. 62">
      <button class="btn btn-primary" style="margin-top:12px" id="saveScore">Save score</button>
    </div>`;
  $("#back").onclick = () => go({ tab: "mocks" });
  if ($("#start")) $("#start").onclick = () => { state.boardMock = { paper: view.paper, end: Date.now() + p.minutes * 60000 }; save(); render(); };
  if ($("#stop")) $("#stop").onclick = () => { state.boardMock = null; save(); render(); };
  $("#saveScore").onclick = () => {
    const v = parseInt($("#score").value, 10);
    if (isNaN(v) || v < 0 || v > p.marks) { toast(`Enter a number from 0 to ${p.marks}`); return; }
    state.mocks.push({ kind: "board", s: p.s, score: v, total: p.marks, date: todayStr() });
    state.boardMock = null; markStudied(); save(); toast("Score saved"); go({ tab: "mocks" });
  };
  if (running) tick = setInterval(() => {
    const l = running.end - Date.now(); const c = $("#bclock");
    if (c) c.textContent = fmt(Math.max(0, l));
    if (l <= 0) { clearInterval(tick); toast("Time is up. Pens down."); }
  }, 1000);
}

// ---------- Mistakes ----------
function renderMistakes() {
  const groups = {};
  state.mistakes.forEach((id) => { const q = byId[id]; if (!q) return; const k = q.s + "-" + q.ch; (groups[k] = groups[k] || []).push(q); });
  const keys = Object.keys(groups).sort((a, b) => groups[b].length - groups[a].length);
  app.innerHTML = `
    <h2>Mistakes</h2>
    <p class="muted small">Every question you get wrong lands here. Answer it correctly once to clear it.</p>
    ${state.mistakes.length ? `<button class="btn btn-primary" id="fix">Fix all ${state.mistakes.length}</button>
    <div class="card">${keys.map((k) => { const [s, ch] = k.split("-");
      return `<div class="row" data-k="${k}"><span class="tag ${s}">${SUBJ[s]}</span><div class="grow">${esc(CHAPTERS[s][ch - 1])}</div><strong>${groups[k].length}</strong></div>`; }).join("")}</div>`
    : `<div class="card" style="text-align:center"><div class="big">0</div><p class="muted">No mistakes waiting. Nice.</p></div>`}`;
  if ($("#fix")) $("#fix").onclick = startMistakeQuiz;
  app.querySelectorAll("[data-k]").forEach((r) => (r.onclick = () => startQuiz({ title: "Fix my mistakes", qs: shuffle(groups[r.dataset.k]), mode: "mistakes" })));
}

// ---------- focus timer ----------
function startFocus() { state.focusMode = "focus"; state.focusEnd = Date.now() + 25 * 60000; markStudied(); save(); showFocus(); }
function showFocus() {
  let ov = $("#focusOv");
  if (!ov) { ov = document.createElement("div"); ov.id = "focusOv"; ov.className = "overlay"; document.body.appendChild(ov); }
  const isBreak = state.focusMode === "break";
  ov.innerHTML = `<div class="muted">${isBreak ? "Break time. Stand up, stretch, drink water." : "Focus. Phone face down, one chapter only."}</div>
    <div class="clock" id="fclock"></div>
    <button class="btn btn-ghost" style="max-width:280px" id="fstop">${isBreak ? "Skip break" : "Stop"}</button>`;
  $("#fstop").onclick = endFocus;
  const upd = () => {
    const l = state.focusEnd - Date.now();
    if (l <= 0) {
      if (state.focusMode === "focus") { state.focusMode = "break"; state.focusEnd = Date.now() + 5 * 60000; save(); toast("25 minutes done. Take a 5-minute break."); showFocus(); }
      else endFocus();
      return;
    }
    const c = $("#fclock"); if (c) c.textContent = fmt(l);
  };
  clearInterval(showFocus._t); showFocus._t = setInterval(upd, 1000); upd();
}
function endFocus() { clearInterval(showFocus._t); state.focusEnd = null; state.focusMode = null; save(); const ov = $("#focusOv"); if (ov) ov.remove(); render(); }

// ---------- settings ----------
function renderSettings() {
  app.innerHTML = `
    <button class="chip" id="back">‹ Back</button>
    <h2 style="margin-top:12px">Settings</h2>
    <div class="card">
      <label for="nm">Name</label><input id="nm" value="${esc(state.name)}">
      <label for="ex">First board exam date</label><input id="ex" type="date" value="${esc(state.examDate)}">
      <p class="muted small">Update this when CBSE releases the 2027 date sheet.</p>
      <button class="btn btn-primary" id="saveSet">Save</button>
    </div>
    <div class="card">
      <h3>Backup</h3>
      <p class="muted small" style="margin:0">Progress is saved only on this phone. Save a backup file every week (for example to Google Drive).</p>
      <div class="btn-row"><button class="btn btn-ghost" id="exp">Save backup</button><button class="btn btn-ghost" id="impBtn">Restore</button></div>
      <input type="file" id="imp" accept="application/json" style="display:none">
    </div>
    <div class="card">
      <h3>About</h3>
      <p class="muted small" style="margin:0">Board Coach v0.1 · ${QUESTIONS.length} practice questions · ${SUBJECTS.map((x) => x.n).join(", ")} · CBSE Class 10. Found a wrong answer? Note it down so it can be fixed in the next version.</p>
    </div>`;
  $("#back").onclick = () => go({ tab: view.tab });
  $("#saveSet").onclick = () => {
    state.name = $("#nm").value.trim() || "Anay";
    if ($("#ex").value) state.examDate = $("#ex").value;
    save(); toast("Saved"); go({ tab: view.tab });
  };
  $("#exp").onclick = () => {
    const blob = new Blob([JSON.stringify(state, null, 1)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `board-coach-backup-${todayStr()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
  };
  $("#impBtn").onclick = () => $("#imp").click();
  $("#imp").onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    f.text().then((t) => { try { state = Object.assign({}, DEFAULT_STATE, JSON.parse(t)); save(); toast("Backup restored"); go({ tab: "today" }); } catch (err) { toast("That file is not a valid backup"); } });
  };
}

// ---------- start ----------
render();
if (state.focusEnd && state.focusEnd > Date.now()) showFocus();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
