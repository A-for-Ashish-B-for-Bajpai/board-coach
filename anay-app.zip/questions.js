// Question bank v0.1. Science and Maths, CBSE Class 10 (NCERT rationalised syllabus).
// Each question: s = subject, ch = chapter number, q = question, o = options, a = index of correct option, e = explanation.
// To add a question, copy one line and change it. Keep the answer index (0 to 3) correct.

const CHAPTERS = {
  sci: [
    "Chemical Reactions and Equations",
    "Acids, Bases and Salts",
    "Metals and Non-metals",
    "Carbon and its Compounds",
    "Life Processes",
    "Control and Coordination",
    "How do Organisms Reproduce?",
    "Heredity",
    "Light: Reflection and Refraction",
    "The Human Eye and the Colourful World",
    "Electricity",
    "Magnetic Effects of Electric Current",
    "Our Environment"
  ],
  math: [
    "Real Numbers",
    "Polynomials",
    "Pair of Linear Equations in Two Variables",
    "Quadratic Equations",
    "Arithmetic Progressions",
    "Triangles",
    "Coordinate Geometry",
    "Introduction to Trigonometry",
    "Some Applications of Trigonometry",
    "Circles",
    "Areas Related to Circles",
    "Surface Areas and Volumes",
    "Statistics",
    "Probability"
  ]
};

const AR = [
  "Both A and R are true, and R is the correct explanation of A",
  "Both A and R are true, but R is not the correct explanation of A",
  "A is true, but R is false",
  "A is false, but R is true"
];

const QUESTIONS = [
  // ---------- SCIENCE ----------
  // 1 Chemical Reactions and Equations
  { s: "sci", ch: 1, q: "Which of these is a decomposition reaction?", o: ["CaO + H₂O → Ca(OH)₂", "2FeSO₄ → Fe₂O₃ + SO₂ + SO₃ (on heating)", "Fe + CuSO₄ → FeSO₄ + Cu", "Na₂SO₄ + BaCl₂ → BaSO₄ + 2NaCl"], a: 1, e: "One compound (ferrous sulphate) breaks into simpler substances on heating, so it is thermal decomposition. The others are combination, displacement and double displacement." },
  { s: "sci", ch: 1, q: "An iron nail is dipped in copper sulphate solution. The colour of the solution changes from:", o: ["Green to blue", "Blue to light green", "Colourless to blue", "Blue to colourless"], a: 1, e: "Iron displaces copper, forming ferrous sulphate (light green). Blue CuSO₄ fades and a brown copper coating forms on the nail." },
  { s: "sci", ch: 1, q: "In the reaction CuO + H₂ → Cu + H₂O, the substance that is oxidised is:", o: ["CuO", "H₂", "Cu", "H₂O"], a: 1, e: "Hydrogen gains oxygen to form water, so H₂ is oxidised. CuO loses oxygen, so it is reduced." },
  { s: "sci", ch: 1, q: "Chips packets are flushed with nitrogen mainly to:", o: ["Make the packet look full", "Prevent rancidity by stopping oxidation of fats", "Keep the chips warm", "Add flavour"], a: 1, e: "Nitrogen is unreactive. It keeps oxygen away, so the oils and fats do not oxidise and turn rancid." },
  { s: "sci", ch: 1, q: "Assertion (A): Calcium oxide reacts vigorously with water and releases a lot of heat.\nReason (R): The reaction of quicklime with water is an exothermic combination reaction.", o: AR, a: 0, e: "CaO + H₂O → Ca(OH)₂ + heat. Two substances combine and heat is released, which explains the vigorous reaction." },
  { s: "sci", ch: 1, q: "White silver chloride turns grey in sunlight. This is an example of:", o: ["Thermal decomposition", "Electrolytic decomposition", "Photolytic decomposition", "Combination"], a: 2, e: "Light breaks 2AgCl into 2Ag + Cl₂. Decomposition by light is photolytic decomposition; grey colour is silver metal." },

  // 2 Acids, Bases and Salts
  { s: "sci", ch: 2, q: "A solution has a pH of 3. It is:", o: ["Neutral", "Weakly basic", "Acidic", "Strongly basic"], a: 2, e: "pH below 7 is acidic. The lower the pH, the stronger the acid; pH 3 is quite acidic." },
  { s: "sci", ch: 2, q: "The chemical formula of baking soda is:", o: ["Na₂CO₃·10H₂O", "NaHCO₃", "CaOCl₂", "CaSO₄·½H₂O"], a: 1, e: "Baking soda is sodium hydrogencarbonate, NaHCO₃. The others are washing soda, bleaching powder and plaster of Paris." },
  { s: "sci", ch: 2, q: "Plaster of Paris is made by heating gypsum at:", o: ["273 K", "373 K", "473 K", "573 K"], a: 1, e: "Gypsum (CaSO₄·2H₂O) heated at 373 K loses water to form CaSO₄·½H₂O, plaster of Paris." },
  { s: "sci", ch: 2, q: "Tooth decay starts when the pH in the mouth falls below:", o: ["7.5", "6.5", "5.5", "4.0"], a: 2, e: "Below pH 5.5, acids from bacteria start to corrode tooth enamel (calcium phosphate)." },
  { s: "sci", ch: 2, q: "Zinc granules react with dilute hydrochloric acid. The gas released is:", o: ["Oxygen", "Chlorine", "Hydrogen", "Carbon dioxide"], a: 2, e: "Zn + 2HCl → ZnCl₂ + H₂. The gas burns with a pop sound, which confirms hydrogen." },

  // 3 Metals and Non-metals
  { s: "sci", ch: 3, q: "Which metal is stored under kerosene?", o: ["Iron", "Sodium", "Copper", "Aluminium"], a: 1, e: "Sodium reacts so vigorously with air and water that it can catch fire, so it is kept in kerosene." },
  { s: "sci", ch: 3, q: "The non-metal that is liquid at room temperature is:", o: ["Mercury", "Bromine", "Iodine", "Sulphur"], a: 1, e: "Bromine is the liquid non-metal. Mercury is a liquid too, but it is a metal." },
  { s: "sci", ch: 3, q: "Ionic compounds conduct electricity:", o: ["In the solid state", "In molten state or in aqueous solution", "Never", "Only as a gas"], a: 1, e: "In solids the ions are fixed. When melted or dissolved, the ions can move and carry current." },
  { s: "sci", ch: 3, q: "Aqua regia is a freshly made mixture of:", o: ["Conc. HCl and conc. HNO₃ in ratio 3 : 1", "Conc. HCl and conc. H₂SO₄ in ratio 1 : 3", "Conc. HNO₃ and conc. H₂SO₄ in ratio 3 : 1", "Conc. HCl and water in ratio 1 : 1"], a: 0, e: "Three parts concentrated hydrochloric acid to one part concentrated nitric acid. It can dissolve gold and platinum." },
  { s: "sci", ch: 3, q: "In electrolytic refining of copper, the impure copper is made the:", o: ["Cathode", "Anode", "Electrolyte", "Container"], a: 1, e: "Impure metal is the anode and dissolves; pure metal deposits on the thin cathode strip." },
  { s: "sci", ch: 3, q: "Assertion (A): Copper does not displace hydrogen from dilute hydrochloric acid.\nReason (R): Copper is more reactive than hydrogen.", o: AR, a: 2, e: "A is true. R is false: copper is below hydrogen in the reactivity series, which is exactly why it cannot displace hydrogen." },
  { s: "sci", ch: 3, q: "Assertion (A): Sodium is stored under water.\nReason (R): Sodium reacts vigorously with oxygen and with water.", o: AR, a: 3, e: "A is false: sodium is stored under kerosene, because it reacts violently with water. R is true." },

  // 4 Carbon and its Compounds
  { s: "sci", ch: 4, q: "How many covalent bonds are there in a molecule of ethane (C₂H₆)?", o: ["6", "7", "8", "10"], a: 1, e: "Six C–H bonds plus one C–C bond make 7 covalent bonds." },
  { s: "sci", ch: 4, q: "The functional group in ethanoic acid is:", o: ["Alcohol (–OH)", "Aldehyde (–CHO)", "Ketone (>C=O)", "Carboxylic acid (–COOH)"], a: 3, e: "Ethanoic acid is CH₃COOH. The –COOH group makes it a carboxylic acid." },
  { s: "sci", ch: 4, q: "The next homologue of CH₃OH is:", o: ["CH₃CHO", "C₂H₅OH", "C₂H₆", "HCOOH"], a: 1, e: "Members of a homologous series differ by –CH₂–. CH₃OH + CH₂ gives C₂H₅OH (ethanol)." },
  { s: "sci", ch: 4, q: "Vegetable oils are turned into vanaspati ghee by:", o: ["Oxidation", "Hydrogenation in the presence of a nickel catalyst", "Esterification", "Saponification"], a: 1, e: "Hydrogen is added to unsaturated oils using a nickel (or palladium) catalyst, making saturated fats." },
  { s: "sci", ch: 4, q: "Ethanol reacts with ethanoic acid in the presence of concentrated H₂SO₄ to form:", o: ["An ester", "A soap", "An alkene", "An aldehyde"], a: 0, e: "This is esterification. The product, ethyl ethanoate, is a sweet-smelling ester." },
  { s: "sci", ch: 4, q: "A soap molecule has:", o: ["Two hydrophobic ends", "A hydrophilic ionic end and a hydrophobic carbon-chain tail", "Two ionic ends", "No charged part"], a: 1, e: "The ionic end dissolves in water, the long tail dissolves in oil. Together they form micelles that lift dirt away." },

  // 5 Life Processes
  { s: "sci", ch: 5, q: "Photosynthesis takes place in the:", o: ["Mitochondria", "Chloroplasts", "Nucleus", "Ribosomes"], a: 1, e: "Chloroplasts contain chlorophyll, which traps light energy to make food." },
  { s: "sci", ch: 5, q: "The functional unit of the human kidney is the:", o: ["Neuron", "Nephron", "Alveolus", "Villus"], a: 1, e: "Each kidney has many nephrons, which filter the blood and form urine." },
  { s: "sci", ch: 5, q: "During heavy exercise, pyruvate in muscle cells is converted (without enough oxygen) into:", o: ["Ethanol and CO₂", "Lactic acid", "CO₂ and water", "Glucose"], a: 1, e: "Lack of oxygen in muscles gives lactic acid, which causes cramps. Yeast gives ethanol and CO₂ instead." },
  { s: "sci", ch: 5, q: "Which blood vessel brings oxygenated blood from the lungs to the heart?", o: ["Pulmonary artery", "Pulmonary vein", "Aorta", "Vena cava"], a: 1, e: "The pulmonary vein is the vein that carries oxygen-rich blood, from the lungs to the left atrium." },
  { s: "sci", ch: 5, q: "Salivary amylase breaks down:", o: ["Proteins", "Fats", "Starch", "Vitamins"], a: 2, e: "Saliva's enzyme amylase starts digesting starch into sugar in the mouth." },
  { s: "sci", ch: 5, q: "In plants, water and minerals are carried by the:", o: ["Phloem", "Xylem", "Stomata", "Cambium"], a: 1, e: "Xylem carries water and minerals up from the roots. Phloem carries food." },

  // 6 Control and Coordination
  { s: "sci", ch: 6, q: "The tiny gap between two neurons is called a:", o: ["Dendrite", "Synapse", "Axon", "Nerve ending"], a: 1, e: "At the synapse, chemicals carry the signal from one neuron to the next." },
  { s: "sci", ch: 6, q: "Which hormone controls the blood sugar level?", o: ["Thyroxine", "Insulin", "Adrenaline", "Growth hormone"], a: 1, e: "Insulin from the pancreas lowers blood sugar. Too little insulin causes diabetes." },
  { s: "sci", ch: 6, q: "The part of the brain that keeps posture and balance is the:", o: ["Cerebrum", "Cerebellum", "Medulla", "Pons"], a: 1, e: "The cerebellum (in the hindbrain) controls balance, posture and precise voluntary movements." },
  { s: "sci", ch: 6, q: "The plant hormone that promotes cell division is:", o: ["Auxin", "Gibberellin", "Cytokinin", "Abscisic acid"], a: 2, e: "Cytokinins promote cell division, for example in fruits and seeds. Abscisic acid inhibits growth." },
  { s: "sci", ch: 6, q: "Lack of iodine in the diet can cause:", o: ["Diabetes", "Goitre", "Dwarfism", "Scurvy"], a: 1, e: "Iodine is needed to make thyroxine. Without it, the thyroid swells, which is goitre." },

  // 7 How do Organisms Reproduce?
  { s: "sci", ch: 7, q: "Amoeba reproduces by:", o: ["Budding", "Binary fission", "Spore formation", "Fragmentation"], a: 1, e: "Amoeba splits into two equal halves. Hydra and yeast use budding; Plasmodium uses multiple fission." },
  { s: "sci", ch: 7, q: "The male reproductive part of a flower is the:", o: ["Pistil", "Stamen", "Sepal", "Ovary"], a: 1, e: "The stamen (anther and filament) produces pollen. The pistil is the female part." },
  { s: "sci", ch: 7, q: "In human females, fertilisation normally takes place in the:", o: ["Uterus", "Ovary", "Fallopian tube (oviduct)", "Vagina"], a: 2, e: "The egg meets the sperm in the oviduct. The zygote then moves to the uterus and implants." },
  { s: "sci", ch: 7, q: "A Copper-T is used as a:", o: ["Hormonal pill", "Device placed in the uterus to prevent pregnancy", "Surgical method", "Barrier worn by males"], a: 1, e: "Copper-T is an intrauterine contraceptive device (IUCD) placed in the uterus." },
  { s: "sci", ch: 7, q: "New plants can grow from buds on the edges of the leaves of:", o: ["Rose", "Bryophyllum", "Wheat", "Mango"], a: 1, e: "Bryophyllum shows vegetative propagation through leaves." },

  // 8 Heredity
  { s: "sci", ch: 8, q: "Mendel crossed pure tall (TT) pea plants with pure dwarf (tt) plants. The F1 plants were:", o: ["All dwarf", "All tall", "Half tall, half dwarf", "Medium height"], a: 1, e: "Every F1 plant is Tt. Tallness is dominant, so all of them are tall." },
  { s: "sci", ch: 8, q: "In a monohybrid cross, the phenotypic ratio in the F2 generation is:", o: ["1 : 1", "1 : 2 : 1", "3 : 1", "9 : 3 : 3 : 1"], a: 2, e: "Tt × Tt gives TT, Tt, Tt, tt: three tall to one dwarf. 1 : 2 : 1 is the genotype ratio." },
  { s: "sci", ch: 8, q: "In a dihybrid cross, the F2 phenotypic ratio is:", o: ["3 : 1", "1 : 2 : 1", "9 : 3 : 3 : 1", "1 : 1 : 1 : 1"], a: 2, e: "With two independently inherited traits, Mendel found the ratio 9 : 3 : 3 : 1." },
  { s: "sci", ch: 8, q: "Human males have the sex chromosomes:", o: ["XX", "XY", "YY", "XO"], a: 1, e: "Males are XY and females are XX." },
  { s: "sci", ch: 8, q: "The sex of a child is decided by:", o: ["The chromosome from the mother", "The chromosome (X or Y) from the father", "The food the mother eats", "Chance alone, with no chromosome involved"], a: 1, e: "All eggs carry X. A sperm carries X (girl) or Y (boy), so the father's chromosome decides." },

  // 9 Light
  { s: "sci", ch: 9, q: "The focal length of a plane mirror is:", o: ["Zero", "25 cm", "Infinity", "Equal to the object distance"], a: 2, e: "A plane mirror can be thought of as a sphere of infinite radius, so its focal length is infinite." },
  { s: "sci", ch: 9, q: "An object is placed at the centre of curvature (C) of a concave mirror. The image is:", o: ["At F, very small", "At C, real, inverted and the same size", "Behind the mirror, virtual and erect", "At infinity"], a: 1, e: "Object at C gives a real, inverted image at C of the same size." },
  { s: "sci", ch: 9, q: "The power of a lens with focal length +50 cm is:", o: ["+0.5 D", "+2 D", "+5 D", "−2 D"], a: 1, e: "P = 1/f in metres = 1/0.5 = +2 dioptre. Positive power means a convex lens." },
  { s: "sci", ch: 9, q: "Glass has a refractive index of 1.5. The speed of light in glass is (c = 3 × 10⁸ m/s):", o: ["4.5 × 10⁸ m/s", "3 × 10⁸ m/s", "2 × 10⁸ m/s", "1.5 × 10⁸ m/s"], a: 2, e: "v = c / n = (3 × 10⁸) / 1.5 = 2 × 10⁸ m/s." },
  { s: "sci", ch: 9, q: "Assertion (A): A concave mirror is used as a shaving mirror.\nReason (R): A concave mirror forms an erect, magnified image when the face is between its pole and focus.", o: AR, a: 0, e: "Within the focus, a concave mirror gives an enlarged, upright image. That is why it works as a shaving mirror." },
  { s: "sci", ch: 9, q: "Rear-view mirrors in vehicles are:", o: ["Plane", "Concave", "Convex", "Cylindrical"], a: 2, e: "Convex mirrors give an erect, smaller image and a wider field of view." },

  // 10 Human Eye
  { s: "sci", ch: 10, q: "Myopia (short-sightedness) is corrected using a:", o: ["Convex lens", "Concave lens", "Bifocal lens only", "Cylindrical lens"], a: 1, e: "In myopia the image forms in front of the retina. A concave (diverging) lens moves it back onto the retina." },
  { s: "sci", ch: 10, q: "The eye lens's ability to change its focal length is called:", o: ["Persistence of vision", "Accommodation", "Dispersion", "Refraction"], a: 1, e: "Ciliary muscles change the lens shape so we can focus on near and far objects. This is accommodation." },
  { s: "sci", ch: 10, q: "The sky looks blue because of:", o: ["Reflection of the sea", "Scattering of light by tiny particles in the air", "Dispersion by water droplets", "Total internal reflection"], a: 1, e: "Tiny air particles scatter shorter (blue) wavelengths much more than red." },
  { s: "sci", ch: 10, q: "Stars twinkle because of:", o: ["Atmospheric refraction", "Reflection from the Moon", "Dispersion", "Their own flickering"], a: 0, e: "Changing layers of air keep bending starlight slightly differently, so the star seems to flicker." },
  { s: "sci", ch: 10, q: "For a young adult with normal vision, the least distance of distinct vision is about:", o: ["10 cm", "25 cm", "50 cm", "1 m"], a: 1, e: "The near point of a normal eye is about 25 cm." },
  { s: "sci", ch: 10, q: "Assertion (A): A rainbow is formed by dispersion of sunlight by water droplets.\nReason (R): The sky appears blue because of scattering of light.", o: AR, a: 1, e: "Both statements are true, but scattering (R) does not explain how a rainbow forms (A)." },

  // 11 Electricity
  { s: "sci", ch: 11, q: "Three resistors of 6 Ω each are connected in parallel. The equivalent resistance is:", o: ["18 Ω", "6 Ω", "3 Ω", "2 Ω"], a: 3, e: "1/R = 1/6 + 1/6 + 1/6 = 3/6, so R = 2 Ω." },
  { s: "sci", ch: 11, q: "A 4 Ω resistor is connected across a 12 V battery. The current is:", o: ["48 A", "3 A", "0.33 A", "16 A"], a: 1, e: "Ohm's law: I = V / R = 12 / 4 = 3 A." },
  { s: "sci", ch: 11, q: "A bulb draws 0.5 A from a 220 V supply. Its power is:", o: ["440 W", "110 W", "220 W", "55 W"], a: 1, e: "P = V × I = 220 × 0.5 = 110 W." },
  { s: "sci", ch: 11, q: "If the length of a wire is doubled (same material and thickness), its resistance:", o: ["Halves", "Stays the same", "Doubles", "Becomes four times"], a: 2, e: "R = ρL/A. Resistance is directly proportional to length." },
  { s: "sci", ch: 11, q: "1 kWh is equal to:", o: ["3.6 × 10⁶ J", "3.6 × 10³ J", "1000 J", "3600 J"], a: 0, e: "1 kWh = 1000 W × 3600 s = 3.6 × 10⁶ J." },
  { s: "sci", ch: 11, q: "Assertion (A): The equivalent resistance of resistors in parallel is less than the smallest resistance.\nReason (R): In parallel, the reciprocal of the equivalent resistance is the sum of the reciprocals of the individual resistances.", o: AR, a: 0, e: "Adding reciprocals makes 1/R larger than any single 1/Rᵢ, so R is smaller than the smallest resistor." },

  // 12 Magnetic Effects
  { s: "sci", ch: 12, q: "The direction of the magnetic field around a straight current-carrying wire is given by the:", o: ["Fleming's left-hand rule", "Right-hand thumb rule", "Fleming's right-hand rule", "Ohm's law"], a: 1, e: "Hold the wire with the thumb along the current; the curled fingers show the field direction." },
  { s: "sci", ch: 12, q: "The direction of force on a current-carrying conductor in a magnetic field is given by:", o: ["Fleming's left-hand rule", "Right-hand thumb rule", "Snell's law", "Lenz's law only"], a: 0, e: "Fleming's left-hand rule: First finger field, seCond finger current, thuMb motion (force)." },
  { s: "sci", ch: 12, q: "Inside a long current-carrying solenoid, the magnetic field lines are:", o: ["Circles", "Parallel straight lines", "Zero", "Random"], a: 1, e: "The field inside is uniform, shown by parallel straight lines." },
  { s: "sci", ch: 12, q: "A fuse protects a circuit by:", o: ["Increasing the voltage", "Melting and breaking the circuit when the current is too high", "Storing extra current", "Earthing the appliance"], a: 1, e: "The fuse wire has a low melting point. Excess current heats and melts it, cutting the circuit." },
  { s: "sci", ch: 12, q: "In domestic wiring (as in the NCERT book), the earth wire has insulation coloured:", o: ["Red", "Black", "Green", "Blue"], a: 2, e: "NCERT convention: live wire red, neutral black, earth green." },

  // 13 Our Environment
  { s: "sci", ch: 13, q: "Which of these is biodegradable?", o: ["Plastic bag", "Glass bottle", "Fruit peels", "DDT"], a: 2, e: "Fruit peels are broken down by microbes. Plastic, glass and DDT are not." },
  { s: "sci", ch: 13, q: "Roughly how much energy passes from one trophic level to the next?", o: ["1%", "10%", "50%", "90%"], a: 1, e: "About 10% is passed on (the 10% law); the rest is used or lost as heat." },
  { s: "sci", ch: 13, q: "The ozone layer is depleted mainly by:", o: ["Carbon dioxide", "CFCs (chlorofluorocarbons)", "Oxygen", "Nitrogen"], a: 1, e: "CFCs from old refrigerants and aerosol sprays break down ozone in the upper atmosphere." },
  { s: "sci", ch: 13, q: "Organisms at the first trophic level are:", o: ["Herbivores", "Carnivores", "Producers (green plants)", "Decomposers"], a: 2, e: "Producers make their own food by photosynthesis and start every food chain." },
  { s: "sci", ch: 13, q: "Biological magnification means:", o: ["Microscopes making organisms look bigger", "Harmful chemicals becoming more concentrated at each higher level of a food chain", "Increase in population", "Plants growing faster"], a: 1, e: "Non-biodegradable chemicals such as pesticides build up, so top consumers get the highest dose." },

  // ---------- MATHS ----------
  // 1 Real Numbers
  { s: "math", ch: 1, q: "HCF of 96 and 404 is:", o: ["2", "4", "8", "12"], a: 1, e: "96 = 2⁵ × 3 and 404 = 2² × 101. Common factor: 2² = 4." },
  { s: "math", ch: 1, q: "For any two positive integers a and b, HCF(a, b) × LCM(a, b) equals:", o: ["a + b", "a × b", "a − b", "a ÷ b"], a: 1, e: "HCF × LCM = product of the two numbers." },
  { s: "math", ch: 1, q: "Which of these is irrational?", o: ["√16", "0.25", "22/7", "√5"], a: 3, e: "√5 cannot be written as p/q. √16 = 4, 0.25 = 1/4 and 22/7 are rational." },
  { s: "math", ch: 1, q: "HCF(26, 91) = 13. Then LCM(26, 91) is:", o: ["182", "2366", "91", "13"], a: 0, e: "LCM = (26 × 91) / 13 = 2366 / 13 = 182." },
  { s: "math", ch: 1, q: "The prime factorisation of 140 is:", o: ["2 × 7 × 10", "2² × 5 × 7", "2³ × 5 × 7", "4 × 5 × 7"], a: 1, e: "140 = 2 × 2 × 5 × 7 = 2² × 5 × 7. Every factor must be prime." },
  { s: "math", ch: 1, q: "Assertion (A): √2 is irrational.\nReason (R): The square root of every prime number is irrational.", o: AR, a: 0, e: "NCERT proves √p is irrational for any prime p; 2 is prime, so R explains A." },

  // 2 Polynomials
  { s: "math", ch: 2, q: "The zeroes of x² − 2x − 8 are:", o: ["4 and −2", "−4 and 2", "8 and −1", "2 and 4"], a: 0, e: "x² − 2x − 8 = (x − 4)(x + 2), so x = 4 or x = −2." },
  { s: "math", ch: 2, q: "The sum of the zeroes of 6x² − 7x − 3 is:", o: ["−7/6", "7/6", "−1/2", "1/2"], a: 1, e: "Sum = −b/a = −(−7)/6 = 7/6. (Product = c/a = −3/6 = −1/2.)" },
  { s: "math", ch: 2, q: "A quadratic polynomial whose zeroes have sum −3 and product 2 is:", o: ["x² − 3x + 2", "x² + 3x + 2", "x² + 2x − 3", "x² − 2x + 3"], a: 1, e: "x² − (sum)x + product = x² − (−3)x + 2 = x² + 3x + 2." },
  { s: "math", ch: 2, q: "A cubic polynomial can have at most how many zeroes?", o: ["1", "2", "3", "4"], a: 2, e: "A polynomial of degree n has at most n zeroes." },
  { s: "math", ch: 2, q: "If 2 is a zero of x² − 5x + k, then k is:", o: ["6", "−6", "10", "4"], a: 0, e: "Put x = 2: 4 − 10 + k = 0, so k = 6." },
  { s: "math", ch: 2, q: "Assertion (A): The graph of y = x² − 4 cuts the x-axis at two points.\nReason (R): A quadratic polynomial always has two real zeroes.", o: AR, a: 2, e: "A is true (x = 2 and x = −2). R is false: x² + 1, for example, has no real zeroes." },

  // 3 Pair of Linear Equations
  { s: "math", ch: 3, q: "Solve: x + y = 14 and x − y = 4.", o: ["x = 9, y = 5", "x = 5, y = 9", "x = 10, y = 4", "x = 8, y = 6"], a: 0, e: "Adding: 2x = 18, so x = 9. Then y = 14 − 9 = 5." },
  { s: "math", ch: 3, q: "If a₁/a₂ = b₁/b₂ ≠ c₁/c₂, the pair of lines is:", o: ["Intersecting, one solution", "Coincident, infinitely many solutions", "Parallel, no solution", "Perpendicular"], a: 2, e: "Equal slopes but different intercepts give parallel lines, so there is no solution." },
  { s: "math", ch: 3, q: "For what value of k does kx + 3y = 3 and 12x + ky = 6 have no solution?", o: ["6", "−6", "±6", "3"], a: 1, e: "Need k/12 = 3/k, so k² = 36, k = ±6. Also 3/k ≠ 3/6, so k ≠ 6. Hence k = −6." },
  { s: "math", ch: 3, q: "The pair 2x + 3y = 9 and 4x + 6y = 18 has:", o: ["No solution", "Exactly one solution", "Exactly two solutions", "Infinitely many solutions"], a: 3, e: "The second equation is 2 × the first. The lines coincide." },
  { s: "math", ch: 3, q: "The sum of two numbers is 20 and their difference is 4. The numbers are:", o: ["12 and 8", "14 and 6", "11 and 9", "10 and 10"], a: 0, e: "x + y = 20, x − y = 4 gives x = 12, y = 8." },

  // 4 Quadratic Equations
  { s: "math", ch: 4, q: "The roots of x² − 3x − 10 = 0 are:", o: ["5 and −2", "−5 and 2", "10 and −1", "3 and −10"], a: 0, e: "(x − 5)(x + 2) = 0, so x = 5 or x = −2." },
  { s: "math", ch: 4, q: "The equation 2x² − 4x + 3 = 0 has:", o: ["Two distinct real roots", "Two equal real roots", "No real roots", "Exactly one root"], a: 2, e: "D = b² − 4ac = 16 − 24 = −8 < 0, so there are no real roots." },
  { s: "math", ch: 4, q: "For x² + kx + 9 = 0 to have equal roots, k must be:", o: ["±3", "±6", "±9", "0"], a: 1, e: "Equal roots need D = 0: k² − 36 = 0, so k = ±6." },
  { s: "math", ch: 4, q: "Which of these is a quadratic equation?", o: ["(x + 1)² = 2(x − 3)", "x(x + 1) + 8 = (x + 2)(x − 2)", "x² + 3x + 1 = (x − 2)²", "2x + 3 = 0"], a: 0, e: "(x + 1)² = 2(x − 3) simplifies to x² + 7 = 0, degree 2. The second and third simplify to linear equations." },
  { s: "math", ch: 4, q: "The product of two consecutive positive integers is 306. The integers are:", o: ["16 and 17", "17 and 18", "18 and 19", "15 and 16"], a: 1, e: "x(x + 1) = 306 gives x² + x − 306 = 0 = (x − 17)(x + 18). So x = 17." },

  // 5 Arithmetic Progressions
  { s: "math", ch: 5, q: "The 10th term of the AP 2, 7, 12, … is:", o: ["45", "47", "50", "52"], a: 1, e: "aₙ = a + (n − 1)d = 2 + 9 × 5 = 47." },
  { s: "math", ch: 5, q: "The sum of the first 10 terms of the AP 2, 7, 12, … is:", o: ["225", "245", "250", "265"], a: 1, e: "Sₙ = n/2 [2a + (n − 1)d] = 5 × [4 + 45] = 245." },
  { s: "math", ch: 5, q: "The common difference of the AP 3, 1, −1, −3, … is:", o: ["2", "−2", "1", "−4"], a: 1, e: "d = 1 − 3 = −2." },
  { s: "math", ch: 5, q: "Which term of the AP 3, 8, 13, … is 78?", o: ["15th", "16th", "17th", "18th"], a: 1, e: "3 + (n − 1)5 = 78, so n − 1 = 15 and n = 16." },
  { s: "math", ch: 5, q: "The sum of the first n odd natural numbers is:", o: ["n", "2n", "n²", "n(n + 1)"], a: 2, e: "1 + 3 + 5 + … has a = 1, d = 2: Sₙ = n/2 [2 + 2(n − 1)] = n²." },

  // 6 Triangles
  { s: "math", ch: 6, q: "In ΔABC, DE ∥ BC with D on AB and E on AC. If AD = 2 cm, DB = 3 cm and AE = 4 cm, then EC is:", o: ["5 cm", "6 cm", "8 cm", "1.5 cm"], a: 1, e: "By the Basic Proportionality Theorem, AD/DB = AE/EC: 2/3 = 4/EC, so EC = 6 cm." },
  { s: "math", ch: 6, q: "ΔABC ~ ΔPQR with AB/PQ = 2/3. If BC = 6 cm, then QR is:", o: ["4 cm", "9 cm", "12 cm", "6 cm"], a: 1, e: "Corresponding sides are in the same ratio: 6/QR = 2/3, so QR = 9 cm." },
  { s: "math", ch: 6, q: "Which of these is NOT a criterion for similarity of triangles?", o: ["AAA", "SSS", "SAS", "SSA"], a: 3, e: "SSA (two sides and a non-included angle) does not guarantee similarity." },
  { s: "math", ch: 6, q: "Which pair of triangles is always similar?", o: ["Two isosceles triangles", "Two right triangles", "Two equilateral triangles", "Two scalene triangles"], a: 2, e: "All angles of any equilateral triangle are 60°, so any two are similar by AAA." },
  { s: "math", ch: 6, q: "The Basic Proportionality Theorem says that a line drawn parallel to one side of a triangle:", o: ["Bisects the triangle", "Divides the other two sides in the same ratio", "Is equal to the third side", "Is perpendicular to the other sides"], a: 1, e: "If DE ∥ BC, then AD/DB = AE/EC." },

  // 7 Coordinate Geometry
  { s: "math", ch: 7, q: "The distance between (2, 3) and (4, 1) is:", o: ["2", "2√2", "4", "√2"], a: 1, e: "√[(4 − 2)² + (1 − 3)²] = √(4 + 4) = √8 = 2√2." },
  { s: "math", ch: 7, q: "The distance of the point (−6, 8) from the origin is:", o: ["2", "10", "14", "√28"], a: 1, e: "√(36 + 64) = √100 = 10." },
  { s: "math", ch: 7, q: "The midpoint of the segment joining (2, −3) and (4, 7) is:", o: ["(3, 2)", "(6, 4)", "(1, 5)", "(3, 5)"], a: 0, e: "((2 + 4)/2, (−3 + 7)/2) = (3, 2)." },
  { s: "math", ch: 7, q: "The point that divides the join of (−1, 7) and (4, −3) in the ratio 2 : 3 is:", o: ["(1, 3)", "(2, 1)", "(3, 1)", "(1, 2)"], a: 0, e: "x = (2×4 + 3×(−1))/5 = 1 and y = (2×(−3) + 3×7)/5 = 3." },
  { s: "math", ch: 7, q: "Any point on the x-axis has coordinates of the form:", o: ["(0, y)", "(x, 0)", "(x, x)", "(0, 0) only"], a: 1, e: "On the x-axis the y-coordinate is 0." },

  // 8 Introduction to Trigonometry
  { s: "math", ch: 8, q: "The value of sin 30° is:", o: ["1/2", "√3/2", "1/√2", "1"], a: 0, e: "sin 30° = 1/2. (cos 30° = √3/2.)" },
  { s: "math", ch: 8, q: "If tan A = 4/3 and A is acute, then sin A is:", o: ["3/5", "4/5", "3/4", "5/4"], a: 1, e: "Opposite 4, adjacent 3, so hypotenuse 5. sin A = 4/5." },
  { s: "math", ch: 8, q: "1 + tan²θ is equal to:", o: ["sec²θ", "cosec²θ", "cos²θ", "1"], a: 0, e: "Divide sin²θ + cos²θ = 1 by cos²θ: tan²θ + 1 = sec²θ." },
  { s: "math", ch: 8, q: "The value of sin 60° cos 30° + sin 30° cos 60° is:", o: ["0", "1/2", "1", "√3"], a: 2, e: "(√3/2)(√3/2) + (1/2)(1/2) = 3/4 + 1/4 = 1." },
  { s: "math", ch: 8, q: "cosec 30° is equal to:", o: ["1/2", "2", "√3", "2/√3"], a: 1, e: "cosec 30° = 1 / sin 30° = 1 / (1/2) = 2." },

  // 9 Applications of Trigonometry
  { s: "math", ch: 9, q: "A tower's shadow is equal to its height. The Sun's angle of elevation is:", o: ["30°", "45°", "60°", "90°"], a: 1, e: "tan θ = height/shadow = 1, so θ = 45°." },
  { s: "math", ch: 9, q: "A kite string is 60 m long and makes 60° with the ground. The height of the kite is:", o: ["30 m", "30√3 m", "60√3 m", "20√3 m"], a: 1, e: "Height = 60 × sin 60° = 60 × √3/2 = 30√3 m." },
  { s: "math", ch: 9, q: "A ladder makes 60° with the ground and its foot is 2 m from the wall. Its length is:", o: ["2 m", "4 m", "2√3 m", "1 m"], a: 1, e: "cos 60° = 2 / length, so length = 2 / (1/2) = 4 m." },
  { s: "math", ch: 9, q: "From a point 30 m from the foot of a tower, the angle of elevation of its top is 30°. The height of the tower is:", o: ["10√3 m", "30√3 m", "15 m", "10 m"], a: 0, e: "tan 30° = h/30, so h = 30/√3 = 10√3 m." },
  { s: "math", ch: 9, q: "The angle of depression of an object is the angle between:", o: ["The line of sight and the vertical", "The horizontal and the line of sight to an object below", "Two lines of sight", "The ground and the object"], a: 1, e: "Looking down at an object, the angle measured from the horizontal is the angle of depression." },

  // 10 Circles
  { s: "math", ch: 10, q: "A tangent to a circle is ______ to the radius at the point of contact.", o: ["Parallel", "Perpendicular", "Equal", "At 45°"], a: 1, e: "The tangent at any point is perpendicular to the radius through that point." },
  { s: "math", ch: 10, q: "How many tangents can be drawn to a circle from a point outside it?", o: ["1", "2", "3", "Infinitely many"], a: 1, e: "Exactly two tangents can be drawn from an external point." },
  { s: "math", ch: 10, q: "The tangent from point Q to a circle is 24 cm long, and Q is 25 cm from the centre. The radius is:", o: ["7 cm", "12 cm", "15 cm", "24.5 cm"], a: 0, e: "Radius ⟂ tangent, so r² = 25² − 24² = 625 − 576 = 49, r = 7 cm." },
  { s: "math", ch: 10, q: "How many tangents can a circle have that are parallel to a given tangent?", o: ["0", "1", "2", "Infinitely many"], a: 1, e: "Only the tangent at the diametrically opposite point is parallel." },
  { s: "math", ch: 10, q: "TP and TQ are tangents from T to a circle with centre O. If ∠POQ = 110°, then ∠PTQ is:", o: ["60°", "70°", "80°", "90°"], a: 1, e: "In quadrilateral OPTQ, the angles at P and Q are 90° each, so ∠PTQ = 360° − 180° − 110° = 70°." },

  // 11 Areas Related to Circles
  { s: "math", ch: 11, q: "The area of a sector of angle θ (in degrees) of a circle of radius r is:", o: ["(θ/360) × 2πr", "(θ/360) × πr²", "(θ/180) × πr²", "πr²θ"], a: 1, e: "Area of sector = (θ/360°) × πr². The arc length is (θ/360°) × 2πr." },
  { s: "math", ch: 11, q: "The area of a sector of radius 6 cm and angle 60° is (use π = 22/7):", o: ["132/7 cm²", "66/7 cm²", "264/7 cm²", "36 cm²"], a: 0, e: "(60/360) × (22/7) × 36 = (1/6) × 792/7 = 132/7 ≈ 18.86 cm²." },
  { s: "math", ch: 11, q: "The length of an arc of radius 21 cm subtending 60° at the centre is (π = 22/7):", o: ["11 cm", "22 cm", "44 cm", "66 cm"], a: 1, e: "(60/360) × 2 × (22/7) × 21 = (1/6) × 132 = 22 cm." },
  { s: "math", ch: 11, q: "A clock's minute hand is 14 cm long. The area it sweeps in 5 minutes is (π = 22/7):", o: ["154/3 cm²", "77/3 cm²", "154 cm²", "616 cm²"], a: 0, e: "In 5 minutes it turns 30°. (30/360) × (22/7) × 196 = 616/12 = 154/3 ≈ 51.33 cm²." },
  { s: "math", ch: 11, q: "The perimeter of a semicircular plate of radius r is:", o: ["πr", "πr + 2r", "2πr", "πr + r"], a: 1, e: "Curved part πr plus the straight diameter 2r." },

  // 12 Surface Areas and Volumes
  { s: "math", ch: 12, q: "Two cubes, each of volume 64 cm³, are joined end to end. The surface area of the cuboid formed is:", o: ["128 cm²", "160 cm²", "192 cm²", "96 cm²"], a: 1, e: "Each side is 4 cm, so the cuboid is 8 × 4 × 4. SA = 2(32 + 16 + 32) = 160 cm²." },
  { s: "math", ch: 12, q: "The total surface area of a solid hemisphere of radius r is:", o: ["2πr²", "3πr²", "4πr²", "πr²"], a: 1, e: "Curved surface 2πr² plus the flat circle πr² = 3πr²." },
  { s: "math", ch: 12, q: "A cylinder and a cone have the same radius and height. The ratio of their volumes is:", o: ["1 : 3", "3 : 1", "2 : 1", "1 : 1"], a: 1, e: "Cylinder πr²h, cone (1/3)πr²h, so the ratio is 3 : 1." },
  { s: "math", ch: 12, q: "The volume of a cone of radius r and height h is:", o: ["πr²h", "(1/3)πr²h", "(2/3)πr³", "(4/3)πr³"], a: 1, e: "Volume of a cone = one-third of the cylinder with the same base and height." },
  { s: "math", ch: 12, q: "The curved surface area of a cylinder of radius 7 cm and height 10 cm is (π = 22/7):", o: ["220 cm²", "440 cm²", "154 cm²", "1540 cm²"], a: 1, e: "CSA = 2πrh = 2 × (22/7) × 7 × 10 = 440 cm²." },

  // 13 Statistics
  { s: "math", ch: 13, q: "The empirical relation between mean, median and mode is:", o: ["3 Median = Mode + 2 Mean", "3 Mean = Mode + 2 Median", "Mode = Mean + Median", "2 Median = Mode + Mean"], a: 0, e: "3 Median = Mode + 2 Mean." },
  { s: "math", ch: 13, q: "The class mark of the class 10–20 is:", o: ["10", "15", "20", "30"], a: 1, e: "Class mark = (lower limit + upper limit)/2 = (10 + 20)/2 = 15." },
  { s: "math", ch: 13, q: "If the mean of a distribution is 30 and the median is 32, the mode is approximately:", o: ["34", "36", "28", "31"], a: 1, e: "Mode = 3 Median − 2 Mean = 96 − 60 = 36." },
  { s: "math", ch: 13, q: "In the formula Mode = l + [(f₁ − f₀)/(2f₁ − f₀ − f₂)] × h, f₁ is the frequency of the:", o: ["Class before the modal class", "Modal class", "Class after the modal class", "First class"], a: 1, e: "f₁ is the modal class frequency, f₀ the class before it and f₂ the class after it." },
  { s: "math", ch: 13, q: "To find the median of grouped data, we first need the:", o: ["Class marks only", "Cumulative frequencies", "Largest frequency only", "Range"], a: 1, e: "The median class is the one whose cumulative frequency first exceeds n/2." },

  // 14 Probability
  { s: "math", ch: 14, q: "The probability of an impossible event is:", o: ["1", "0", "0.5", "−1"], a: 1, e: "An event that can never happen has probability 0." },
  { s: "math", ch: 14, q: "A die is thrown once. The probability of getting a prime number is:", o: ["1/3", "1/2", "2/3", "1/6"], a: 1, e: "Primes on a die: 2, 3, 5. That is 3 out of 6 = 1/2." },
  { s: "math", ch: 14, q: "If P(E) = 0.05, then P(not E) is:", o: ["0.05", "0.5", "0.95", "1.05"], a: 2, e: "P(E) + P(not E) = 1, so P(not E) = 1 − 0.05 = 0.95." },
  { s: "math", ch: 14, q: "A card is drawn from a well-shuffled deck of 52 cards. The probability of a red king is:", o: ["1/13", "1/26", "1/52", "2/13"], a: 1, e: "There are 2 red kings (hearts and diamonds): 2/52 = 1/26." },
  { s: "math", ch: 14, q: "Two coins are tossed together. The probability of getting at least one head is:", o: ["1/4", "1/2", "3/4", "1"], a: 2, e: "Outcomes: HH, HT, TH, TT. Three of the four have at least one head." },
  { s: "math", ch: 14, q: "Assertion (A): The probability of getting 7 when a normal die is thrown is 0.\nReason (R): The probability of an impossible event is 0.", o: AR, a: 0, e: "A die has only 1 to 6, so getting 7 is impossible, which has probability 0." }
];

// Official CBSE sample papers for 2026-27 (board exam 2027).
const SAMPLE_PAPERS = [
  { s: "sci", title: "Science sample paper 2026-27", url: "https://cbseacademic.nic.in/web_material/SQP/ClassX_2026_27/Science-SQP.pdf", marks: 80, minutes: 180 },
  { s: "math", title: "Maths Standard sample paper 2026-27", url: "https://cbseacademic.nic.in/web_material/SQP/ClassX_2026_27/MathsStandard-SQP.pdf", marks: 80, minutes: 180 },
  { s: "math", title: "Maths Basic sample paper 2026-27", url: "https://cbseacademic.nic.in/web_material/SQP/ClassX_2026_27/MathsBasic-SQP.pdf", marks: 80, minutes: 180 }
];
const SQP_PAGE = "https://cbseacademic.nic.in/sqp_classx_2026-27.html";
const NCERT_BOOKS = {
  sci: "https://ncert.nic.in/textbook.php?jesc1=0-13",
  math: "https://ncert.nic.in/textbook.php?jemh1=0-14"
};
